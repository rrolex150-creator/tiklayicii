package com.benim.tiklayici

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs

class ClickService : AccessibilityService() {

    companion object {
        var inst: ClickService? = null
        const val MAXS = 10
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null

    @Volatile private var tplBuff: Array<IntArray?> = arrayOfNulls(MAXS)
    // Nişan / El düğmeleri (oyuna göre ayarlanır)
    private var nX = -1f
    private var nY = -1f
    private var hX = -1f
    private var hY = -1f
    private var nMode = 0          // 0 = takip yok, 1 = aktif / pasif görünümünü izle
    private var nTplP: IntArray? = null
    private var nTplA: IntArray? = null
    private val smode = IntArray(MAXS)   // 0 = süreyle, 1 = sol üst ikon, 2 = düğmeyi izle
    private val sTplP = arrayOfNulls<IntArray>(MAXS)
    private val sTplA = arrayOfNulls<IntArray>(MAXS)
    private var curGame = -1
    private var pScale = 1f
    private val gamePkgs = Array(Cfg.GNAME.size) { "" }
    private var menuSv: ScrollView? = null
    private var lastScroll = 0
    private var panelLogo: ImageView? = null
    private var strip: Array<Array<ImageView?>> = Array(0) { arrayOfNulls<ImageView>(MAXS) }

    // ayarlar
    private val skillOn = BooleanArray(MAXS)
    private val bx = FloatArray(MAXS)
    private val by = FloatArray(MAXS)
    private val secs = IntArray(MAXS)
    private val thr = FloatArray(MAXS) { 22f }
    private val useTimer = BooleanArray(MAXS)
    private val noSee = IntArray(MAXS)
    private val verifyAt = LongArray(MAXS)
    private var iconRow: LinearLayout? = null
    private val panelIcons = ArrayList<ImageView>()
    private val panelIdx = ArrayList<Int>()
    private var profile = 0
    private var nSk = 3
    private var gamePkg = ""
    private var inGame = false
    private var nisanOn = true
    private var pickOn = true
    private var pickMs = 500
    private var evPkg = ""
    private var learnPt: FloatArray? = null
    private var learnIdx = 0
    private var learnAfter = 0L
    private val iconCache = HashMap<String, BitmapDrawable>()

    // durum
    var running = false
    private var busy = false
    private var busySince = 0L
    private val present = BooleanArray(MAXS)
    private val miss = IntArray(MAXS)
    private val lastCast = LongArray(MAXS)
    private var nisanState = 0      // 0 = bilinmiyor, 1 = pasif, 2 = aktif
    private var scoreP = 99f
    private var scoreA = 99f
    private val scoreB = FloatArray(MAXS) { 99f }
    private var lastTap = 0L
    private var lastNisan = 0L
    private var nisanShotAt = 0L
    private var autoBusy = false
    private var panelLp: WindowManager.LayoutParams? = null
    private var outCount = 0
    private var resumeAfter = false
    private var skillLock = 0L
    private var startAt = 0L
    private var nisanCount = 0
    private var skillCount = 0
    private var pickCount = 0
    private var tgtCount = 0
    private var aX = -1f
    private var aY = -1f
    private var aOn = false
    private var atkMs = 400
    private var tgtMs = 2500
    private var tgtOff = 1
    private var lastTgt = 0L
    private var tgtRad = 0
    private var potOn = false
    private var potSec = 20
    private var pX = -1f
    private var pY = -1f
    private var lastPot = 0L
    private var restUntil = 0L
    private var scanGap = 30L
    private var hMode = 0
    private var hTplP: IntArray? = null
    private var hTplA: IntArray? = null
    private var hState = 0
    private var lastHandTap = 0L
    private var rvOn = false
    private var rvT: IntArray? = null
    private var rvFx = -1f
    private var rvFy = -1f
    private var rvWait = 8
    private var rvLastTap = 0L
    private var rvCount = 0
    private val RVW = 48
    private val RVH = 14
    private val gTpl = arrayOfNulls<IntArray>(MAXS)
    private val gSz = FloatArray(MAXS)
    private val gX = FloatArray(MAXS)
    private val gY = FloatArray(MAXS)
    private val gFull = LongArray(MAXS)
    private var mTab = 0
    private var selSk = -1

    private class GL(val tpl: String, val s: Float, val x: Float, val y: Float)
    private val recastGap = 1800L
    private val castLockMs = 650L
    private val nisanGap = 350L

    // arayüz
    private var panel: View? = null
    private var menu: View? = null
    private var menuLp: WindowManager.LayoutParams? = null
    private var menuShown = false
    private var startBtn: ImageView? = null
    private var timeText: TextView? = null
    private var statusText: TextView? = null

    // mavi - siyah tema
    private val cBg = 0xF00A1426.toInt()
    private val cStone = 0xFF142640.toInt()
    private val cStroke = 0xFF2E6FB5.toInt()
    private val cAccent = 0xFF2A8CFF.toInt()
    private val cCyan = 0xFF38C6FF.toInt()
    private val cText = 0xFFEAF5FF.toInt()
    private val cMuted = 0xFF7DA3CC.toInt()

    // ---------------- yardımcılar ----------------

    private fun decodeTpl(b64: String): IntArray {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        return IntArray(bytes.size) { bytes[it].toInt() and 255 }
    }

    private fun removeSafe(v: View?) {
        if (v == null) return
        try {
            wm?.removeView(v)
        } catch (ex: Exception) {
        }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun screen(): IntArray {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm?.defaultDisplay?.getRealMetrics(m)
        return intArrayOf(m.widthPixels.coerceAtLeast(1), m.heightPixels.coerceAtLeast(1))
    }

    private fun gname(g: Int): String {
        val n = prefs.getString("gn_" + g, "") ?: ""
        return if (g >= 3 && n.isNotEmpty()) n else Cfg.GNAME[g]
    }

    private fun pname(): String = gname(Cfg.PGAME[profile]) + " · " + Cfg.PNAME[profile]

    // cam görünümlü mavi arka plan
    private fun glass(rDp: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xF00B1B38.toInt(), 0xF0040812.toInt(), 0xF00B2347.toInt()))
        g.cornerRadius = dpx(rDp).toFloat()
        g.setStroke(dpx(1), 0x993AA0FF.toInt())
        return g
    }

    private fun logoRes(g: Int): Int = R.drawable.ic_logo

    private fun firstProfile(g: Int): Int {
        for (k in 0 until Cfg.PGAME.size) {
            if (Cfg.PGAME[k] == g) return k
        }
        return 0
    }

    private fun loadCfg() {
        loadMt()
        profile = prefs.getInt("profile", 0).coerceIn(0, Cfg.PNAME.size - 1)
        nSk = Cfg.SNAME[profile].size
        val pk = "p" + profile + "_"
        nisanOn = prefs.getBoolean(pk + "nisan", Cfg.NON[profile])
        pickOn = prefs.getBoolean(pk + "pick", Cfg.HON[profile])
        pickMs = prefs.getInt(pk + "pickms", 500)
        aOn = prefs.getBoolean(pk + "atk", Cfg.AON[profile])
        atkMs = prefs.getInt(pk + "atkms", 400)
        tgtMs = prefs.getInt(pk + "tgtms", 2500)
        tgtOff = prefs.getInt(pk + "tgtoff", 1)
        tgtRad = prefs.getInt(pk + "tgtrad", 0)
        potOn = prefs.getBoolean(pk + "pot", false)
        potSec = prefs.getInt(pk + "potsec", 20)
        pX = prefs.getFloat(pk + "px", -1f)
        pY = prefs.getFloat(pk + "py", -1f)
        aX = prefs.getFloat(pk + "ax", Cfg.AX[profile])
        aY = prefs.getFloat(pk + "ay", Cfg.AY[profile])
        nX = prefs.getFloat(pk + "nx", Cfg.NX[profile])
        nY = prefs.getFloat(pk + "ny", Cfg.NY[profile])
        hX = prefs.getFloat(pk + "hx", Cfg.HX[profile])
        hY = prefs.getFloat(pk + "hy", Cfg.HY[profile])
        nMode = prefs.getInt(pk + "nmode", Cfg.NMODE[profile])
        hMode = prefs.getInt(pk + "hmode", 0)
        val hps = prefs.getString(pk + "hp", null)
        val has = prefs.getString(pk + "ha", null)
        hTplP = if (hps != null) decodeTpl(hps) else null
        hTplA = if (has != null) decodeTpl(has) else null
        rvOn = prefs.getBoolean(pk + "rv", Cfg.AON[profile])
        rvWait = prefs.getInt(pk + "rvwait", 8)
        val rvs = prefs.getString(pk + "rvt", null)
        rvT = if (rvs != null) decodeTpl(rvs) else null
        rvFx = prefs.getFloat(pk + "rvx", -1f)
        rvFy = prefs.getFloat(pk + "rvy", -1f)
        scanGap = prefs.getInt("scangap", 30).toLong().coerceIn(30L, 600L)
        val nps = prefs.getString(pk + "np", null)
        val nas = prefs.getString(pk + "na", null)
        val builtin = Cfg.NMODE[profile] == 1
        nTplP = if (nps != null) decodeTpl(nps) else if (builtin) decodeTpl(Cfg.T_NP) else null
        nTplA = if (nas != null) decodeTpl(nas) else if (builtin) decodeTpl(Cfg.T_NA) else null
        val tp = arrayOfNulls<IntArray>(MAXS)
        for (i in 0 until MAXS) {
            present[i] = false
            smode[i] = 0
            sTplP[i] = null
            sTplA[i] = null
            gTpl[i] = null
            if (i >= nSk) {
                bx[i] = -1f
                by[i] = -1f
                skillOn[i] = false
                continue
            }
            val k = "s" + profile + "_" + i + "_"
            val fixed = Cfg.SFIXED[profile][i]
            val dx = Cfg.SX[profile][i]
            val dy = Cfg.SY[profile][i]
            val secDef = Cfg.SSEC[profile][i]
            val tStr: String? = null
            bx[i] = if (fixed) Cfg.SX[profile][i] else prefs.getFloat(k + "x", dx)
            by[i] = if (fixed) Cfg.SY[profile][i] else prefs.getFloat(k + "y", dy)
            secs[i] = prefs.getInt(k + "sec", secDef)
            skillOn[i] = prefs.getBoolean(k + "on", defaultOn(profile, i))
            smode[i] = if (fixed) 1 else prefs.getInt(k + "mode", Cfg.SMODE[profile][i])
            val learned = prefs.getString(k + "t", tStr)
            val def = Cfg.STPL[profile][i]
            thr[i] = Cfg.BTH
            if (smode[i] == 1) {
                val gs = prefs.getString(k + "g", null)
                val gd = if (gs != null) decodeTpl(gs) else null
                if (gd != null && gd.size == 24 * 24 * 3) {
                    gTpl[i] = gd
                    gSz[i] = prefs.getFloat(k + "gs", 0.045f)
                    gX[i] = prefs.getFloat(k + "gx", 0.05f)
                    gY[i] = prefs.getFloat(k + "gy", 0.08f)
                    gFull[i] = 0L
                    tp[i] = gd
                    thr[i] = 26f
                } else if (fixed && def != null) {
                    tp[i] = decodeTpl(def)
                } else if (learned != null) {
                    tp[i] = decodeTpl(learned)
                } else if (def != null) {
                    tp[i] = decodeTpl(def)
                    thr[i] = Cfg.STHR[profile][i]
                }
            } else if (smode[i] == 2) {
                val bp = prefs.getString(k + "bp", null)
                val ba = prefs.getString(k + "ba", null)
                if (bp != null && ba != null) {
                    sTplP[i] = decodeTpl(bp)
                    sTplA[i] = decodeTpl(ba)
                }
            }
        }
        tplBuff = tp
        if (!running) timeText?.text = pname()
        rebuildPanelIcons()
    }

    private fun defaultOn(p: Int, i: Int): Boolean =
        if (p == 0) prefs.getBoolean("b" + i, Cfg.SON[0][i]) else Cfg.SON[p][i]

    private fun skillEnabled(p: Int, i: Int): Boolean =
        if (p == profile) skillOn[i] else prefs.getBoolean("s" + p + "_" + i + "_on", defaultOn(p, i))

    private fun iconOf(b64: String): BitmapDrawable {
        val got = iconCache[b64]
        if (got != null) return got
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        val d = BitmapDrawable(resources, bmp)
        d.setFilterBitmap(false)
        iconCache[b64] = d
        return d
    }

    // 2x2 renk hâlli resmin sol üst çeyreği
    private fun qIcon(b64: String): BitmapDrawable {
        val got = iconCache["q" + b64]
        if (got != null) return got
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        val h = bmp.width / 2 - 2
        val cr = Bitmap.createBitmap(bmp, 0, 0, h, h)
        val d = BitmapDrawable(resources, cr)
        d.setFilterBitmap(true)
        iconCache["q" + b64] = d
        return d
    }

    private fun skillIcon(idx: Int): BitmapDrawable = qIcon(Cfg.SICON[profile][idx])

    // Yüzen penceredeki ikon şeridi: sadece açık olanlar görünür
    private fun rebuildPanelIcons() {
        val row = iconRow ?: return
        row.removeAllViews()
        panelIcons.clear()
        panelIdx.clear()
        fun add(idx: Int, d: BitmapDrawable) {
            val iv = ImageView(this)
            iv.setImageDrawable(d)
            iv.alpha = 0.35f
            val isz = (dpx(24) * pScale).toInt()
            val p = LinearLayout.LayoutParams(isz, isz)
            p.rightMargin = (dpx(3) * pScale).toInt()
            row.addView(iv, p)
            panelIcons.add(iv)
            panelIdx.add(idx)
        }
        if (nisanOn && nX >= 0f) add(-1, iconOf(Cfg.IC_NISAN))
        if (pickOn && hX >= 0f) add(-2, iconOf(Cfg.IC_EL))
        for (i in 0 until nSk) {
            if (skillOn[i] && bx[i] >= 0f) add(i, skillIcon(i))
        }
        updateStatus()
    }

    // ---------------- dokunma ----------------

    private fun tapFrac(fx: Float, fy: Float) {
        val s = screen()
        val j = 0.004f * s[1]
        val x = (fx * s[0] + (Math.random().toFloat() * 2f - 1f) * j).coerceIn(0f, s[0] - 1f)
        val y = (fy * s[1] + (Math.random().toFloat() * 2f - 1f) * j).coerceIn(0f, s[1] - 1f)
        val path = Path()
        path.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(g, null, null)
        lastTap = SystemClock.elapsedRealtime()
    }

    // ---------------- görüntü analizi (şablon eşleştirme) ----------------

    // Küçük skor = şablon bulundu. Ortalama mutlak renk farkı döner.
    private fun slide(px: IntArray, rw: Int, rh: Int, t: IntArray, tw: Int, th: Int): Float {
        val n = tw * th * 3
        var best = Int.MAX_VALUE
        for (y in 0..(rh - th)) {
            for (x in 0..(rw - tw)) {
                var s = 0
                var ti = 0
                var yy = 0
                while (yy < th) {
                    var p = (y + yy) * rw + x
                    var xx = 0
                    while (xx < tw) {
                        val c = px[p++]
                        s += abs(((c shr 16) and 255) - t[ti]) +
                            abs(((c shr 8) and 255) - t[ti + 1]) +
                            abs((c and 255) - t[ti + 2])
                        ti += 3
                        xx++
                    }
                    if (s >= best) break
                    yy++
                }
                if (s < best) best = s
            }
        }
        return best.toFloat() / n
    }

    // Sol üst buff satırı: Hava Kılıcı, Öfke ve (öğretildiyse) Buds ikonları var mı?
    private fun analyzeBuffs(b: Bitmap, tpls: Array<IntArray?>): FloatArray {
        val out = FloatArray(MAXS) { 99f }
        val sc = b.height / 1080f
        val x0 = (0.03f * b.width).toInt()
        val x1 = (0.30f * b.width).toInt()
        val y0 = (0.12f * b.height).toInt()
        val y1 = (0.22f * b.height).toInt()
        val f = 0.5f / sc
        val rw = ((x1 - x0) * f).toInt()
        val rh = ((y1 - y0) * f).toInt()
        if (rw < Cfg.TW + 2 || rh < Cfg.TH + 2) return out
        val reg = Bitmap.createBitmap(b, x0, y0, x1 - x0, y1 - y0)
        val small = Bitmap.createScaledBitmap(reg, rw, rh, true)
        val px = IntArray(rw * rh)
        small.getPixels(px, 0, rw, 0, 0, rw, rh)
        for (i in 0 until MAXS) {
            val t = tpls[i] ?: continue
            if (gTpl[i] != null) continue
            out[i] = slide(px, rw, rh, t, Cfg.TW, Cfg.TH)
        }
        return out
    }

    // Dokunulan buff ikonunu şablon olarak kaydet (yarım ölçek, 21x20)
    private fun learnIcon(b: Bitmap, fx: Float, fy: Float): String? {
        val sc = b.height / 1080f
        val w = (Cfg.TW * 2 * sc).toInt()
        val h = (Cfg.TH * 2 * sc).toInt()
        val cx = (fx * b.width).toInt()
        val cy = (fy * b.height).toInt()
        val x0 = (cx - w / 2).coerceIn(0, b.width - w)
        val y0 = (cy - h / 2).coerceIn(0, b.height - h)
        val crop = Bitmap.createBitmap(b, x0, y0, w, h)
        val small = Bitmap.createScaledBitmap(crop, Cfg.TW, Cfg.TH, true)
        val px = IntArray(Cfg.TW * Cfg.TH)
        small.getPixels(px, 0, Cfg.TW, 0, 0, Cfg.TW, Cfg.TH)
        val bytes = ByteArray(px.size * 3)
        for (i in px.indices) {
            bytes[i * 3] = ((px[i] shr 16) and 255).toByte()
            bytes[i * 3 + 1] = ((px[i] shr 8) and 255).toByte()
            bytes[i * 3 + 2] = (px[i] and 255).toByte()
        }
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    // Bir düğmenin çevresinde pasif ve aktif görünümü arar: [pasif skoru, aktif skoru]
    private fun analyzeSlot(b: Bitmap, fx: Float, fy: Float, tP: IntArray?, tA: IntArray?, rad: Float): FloatArray {
        val none = floatArrayOf(99f, 99f)
        if (fx < 0f || fy < 0f || tP == null || tA == null) return none
        val need = Cfg.NT * Cfg.NT * 3
        if (tP.size < need || tA.size < need) return none
        val sc = b.height / 1080f
        val cx = (fx * b.width).toInt()
        val cy = (fy * b.height).toInt()
        val r = (rad * sc).toInt()
        val x0 = (cx - r).coerceAtLeast(0)
        val y0 = (cy - r).coerceAtLeast(0)
        val x1 = (cx + r).coerceAtMost(b.width)
        val y1 = (cy + r).coerceAtMost(b.height)
        val f = 0.25f / sc
        val rw = ((x1 - x0) * f).toInt()
        val rh = ((y1 - y0) * f).toInt()
        if (rw < Cfg.NT + 2 || rh < Cfg.NT + 2) return none
        val reg = Bitmap.createBitmap(b, x0, y0, x1 - x0, y1 - y0)
        val small = Bitmap.createScaledBitmap(reg, rw, rh, true)
        val px = IntArray(rw * rh)
        small.getPixels(px, 0, rw, 0, 0, rw, rh)
        return floatArrayOf(
            slide(px, rw, rh, tP, Cfg.NT, Cfg.NT),
            slide(px, rw, rh, tA, Cfg.NT, Cfg.NT)
        )
    }

    // Düğmenin çevresini kırpıp şablon (çeyrek ölçek, 29x29 RGB) olarak döndürür
    private fun cropTpl(b: Bitmap, fx: Float, fy: Float): String? {
        val sc = b.height / 1080f
        val w = (Cfg.NT * 4 * sc).toInt()
        if (w < 8 || w > b.width || w > b.height) return null
        val cx = (fx * b.width).toInt()
        val cy = (fy * b.height).toInt()
        val x0 = (cx - w / 2).coerceIn(0, b.width - w)
        val y0 = (cy - w / 2).coerceIn(0, b.height - w)
        val crop = Bitmap.createBitmap(b, x0, y0, w, w)
        val small = Bitmap.createScaledBitmap(crop, Cfg.NT, Cfg.NT, true)
        val px = IntArray(Cfg.NT * Cfg.NT)
        small.getPixels(px, 0, Cfg.NT, 0, 0, Cfg.NT, Cfg.NT)
        val bytes = ByteArray(px.size * 3)
        for (i in px.indices) {
            bytes[i * 3] = ((px[i] shr 16) and 255).toByte()
            bytes[i * 3 + 1] = ((px[i] shr 8) and 255).toByte()
            bytes[i * 3 + 2] = (px[i] and 255).toByte()
        }
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    // İki şablon ne kadar farklı (ortalama mutlak fark)
    private fun tplDiff(x: String, y: String): Float {
        val a = decodeTpl(x)
        val b = decodeTpl(y)
        val n = minOf(a.size, b.size)
        if (n == 0) return 0f
        var s = 0L
        for (i in 0 until n) {
            s += abs(a[i] - b[i])
        }
        return s.toFloat() / n
    }

    // ---------- otomatik ikon öğrenme ("Dene" düğmesi) ----------

    private fun grab(cb: (Bitmap?) -> Unit) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hb = r.hardwareBuffer
                        bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                    } catch (ex: Exception) {
                    }
                    cb(bmp)
                }

                override fun onFailure(code: Int) {
                    cb(null)
                }
            })
        } catch (ex: Exception) {
            cb(null)
        }
    }

    // Basmadan önceki ve sonraki görüntüyü karşılaştırır, sol üstteki buff satırında
    // yeni çıkan ikonu bulup şablon olarak döndürür. Bulamazsa null.
    private fun diffLearn(a: Bitmap, b: Bitmap): String? {
        if (a.width != b.width || a.height != b.height) return null
        val sc = b.height / 1080f
        val half = (16 * sc).toInt().coerceAtLeast(4)
        val cy = (170f * sc).toInt()
        var bestK = -1
        var bestD = 0f
        var second = 0f
        for (k in 0 until 12) {
            val cx = ((138f + 49f * k) * sc).toInt()
            if (cx - half < 0 || cy - half < 0 || cx + half >= b.width || cy + half >= b.height) continue
            var sum = 0L
            var n = 0
            var y = cy - half
            while (y < cy + half) {
                var x = cx - half
                while (x < cx + half) {
                    val p = a.getPixel(x, y)
                    val q = b.getPixel(x, y)
                    sum += abs(((p shr 16) and 255) - ((q shr 16) and 255)) +
                        abs(((p shr 8) and 255) - ((q shr 8) and 255)) +
                        abs((p and 255) - (q and 255))
                    n++
                    x += 3
                }
                y += 3
            }
            val d = sum.toFloat() / (n * 3)
            if (d > bestD) {
                second = bestD
                bestD = d
                bestK = k
            } else if (d > second) {
                second = d
            }
        }
        if (bestK < 0 || bestD < 14f || bestD < second * 1.4f) return null
        val fx = ((138f + 49f * bestK) * sc) / b.width
        val fy = (170f * sc) / b.height
        return learnIcon(b, fx, fy)
    }

    // Ortak öğrenme akışı: menüyü ve pencereyi gizler, ekran görüntüsü alır, sonucu kaydeder.
    // twoStep: önce görüntü al, düğmeye bas, 1 sn sonra tekrar görüntü al. untap: tekrar bas (aç/kapa düğmeleri).
    private fun runShot(
        twoStep: Boolean, fx: Float, fy: Float, untap: Boolean,
        calc: (Bitmap, Bitmap?) -> Boolean, okMsg: String, failMsg: String
    ) {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Android 11 veya üstü gerekli")
            return
        }
        if (fx < 0f || fy < 0f) {
            toast("Önce yuvayı ayarla")
            return
        }
        if (autoBusy) return
        autoBusy = true
        showMenu(false)
        panel?.visibility = View.INVISIBLE
        toast("Öğreniyor, bekle...")
        fun finish(msg: String) {
            autoBusy = false
            panel?.visibility = if (inGame) View.VISIBLE else View.GONE
            showMenu(true)
            toast(msg)
        }
        handler.postDelayed({
            grab { a ->
                if (a == null) {
                    handler.post { finish("Ekran görüntüsü alınamadı") }
                } else if (!twoStep) {
                    var ok = false
                    try {
                        ok = calc(a, null)
                    } catch (ex: Exception) {
                    }
                    handler.post { finish(if (ok) okMsg else failMsg) }
                } else {
                    handler.post {
                        tapFrac(fx, fy)
                        handler.postDelayed({
                            grab { b ->
                                var ok = false
                                if (b != null) {
                                    try {
                                        ok = calc(a, b)
                                    } catch (ex: Exception) {
                                    }
                                }
                                handler.post {
                                    if (untap) tapFrac(fx, fy)
                                    finish(if (ok) okMsg else failMsg)
                                }
                            }
                        }, 1000L)
                    }
                }
            }
        }, 700L)
    }

    // Sol üst buff ikonunu otomatik öğren (beceri kapalıyken bas, yeni çıkan ikonu bul)
    private fun autoLearn(idx: Int) {
        val pf = profile
        val kk = "s" + pf + "_" + idx + "_"
        runShot(true, bx[idx], by[idx], false, { a, b ->
            val r = if (b != null) diffLearnG(a, b) else null
            if (r != null) {
                prefs.edit().putString(kk + "g", r.tpl).putFloat(kk + "gs", r.s)
                    .putFloat(kk + "gx", r.x).putFloat(kk + "gy", r.y).commit()
                useTimer[idx] = false
                noSee[idx] = 0
                true
            } else {
                false
            }
        }, Cfg.SNAME[pf][idx] + " ikonu öğrenildi", "Yeni ikon çıkmadı. Buff yokken tekrar dene")
    }

    // Düğmenin pasif ve aktif görünümünü otomatik öğren (pasifken bas, sonra aktif hâlini kaydet)
    private fun autoLearnBtn(kP: String, kA: String, fx: Float, fy: Float, untap: Boolean, name: String) {
        runShot(true, fx, fy, untap, { a, b ->
            val tp = cropTpl(a, fx, fy)
            val ta = if (b != null) cropTpl(b, fx, fy) else null
            if (tp != null && ta != null && tplDiff(tp, ta) >= 8f) {
                prefs.edit().putString(kP, tp).putString(kA, ta).commit()
                true
            } else {
                false
            }
        }, name + ": pasif ve aktif görünüm öğrenildi",
            "Düğmenin görünümü değişmedi. Pasifken dene ya da bu düğmede takip yok de")
    }

    // Düğmenin şu anki görünümünü kaydet (pasif ya da aktif, sen seçersin)

    // En iyi eşleşme ve yeri: [skor, x, y]
    private fun slideXY(px: IntArray, rw: Int, rh: Int, t: IntArray, tw: Int, th: Int): FloatArray {
        val n = tw * th * 3
        var best = Int.MAX_VALUE
        var bxx = 0
        var byy = 0
        for (y in 0..(rh - th)) {
            for (x in 0..(rw - tw)) {
                var sm = 0
                var ti = 0
                var yy = 0
                while (yy < th) {
                    var p = (y + yy) * rw + x
                    var xx = 0
                    while (xx < tw) {
                        val c = px[p++]
                        sm += abs(((c shr 16) and 255) - t[ti]) +
                            abs(((c shr 8) and 255) - t[ti + 1]) +
                            abs((c and 255) - t[ti + 2])
                        ti += 3
                        xx++
                    }
                    if (sm >= best) break
                    yy++
                }
                if (sm < best) {
                    best = sm
                    bxx = x
                    byy = y
                }
            }
        }
        return floatArrayOf(best.toFloat() / n, bxx.toFloat(), byy.toFloat())
    }

    // Öğrenilmiş buff ikonlarını (her yerleşimde) ara: önce son yerinin çevresi, bulunamazsa sol üst bölge
    private fun analyzeBuffG(b: Bitmap, out: FloatArray) {
        val now = SystemClock.elapsedRealtime()
        for (i in 0 until MAXS) {
            val t = gTpl[i] ?: continue
            val s = gSz[i] * b.height
            if (s < 8f) continue
            val f = 24f / s
            var found = false
            // 1) son konumun çevresi
            val lx = gX[i] * b.width
            val ly = gY[i] * b.height
            var x0 = (lx - 3.2f * s).toInt().coerceAtLeast(0)
            var y0 = (ly - 1.7f * s).toInt().coerceAtLeast(0)
            var x1 = (lx + 3.2f * s).toInt().coerceAtMost(b.width)
            var y1 = (ly + 1.7f * s).toInt().coerceAtMost(b.height)
            for (pass in 0..1) {
                if (pass == 1) {
                    if (found || now - gFull[i] < 700L) break
                    gFull[i] = now
                    x0 = 0
                    y0 = 0
                    x1 = (0.40f * b.width).toInt()
                    y1 = (0.34f * b.height).toInt()
                }
                val rw = ((x1 - x0) * f).toInt()
                val rh = ((y1 - y0) * f).toInt()
                if (rw < 26 || rh < 26 || x1 - x0 < 4 || y1 - y0 < 4) continue
                val reg = Bitmap.createBitmap(b, x0, y0, x1 - x0, y1 - y0)
                val small = Bitmap.createScaledBitmap(reg, rw, rh, true)
                val px = IntArray(rw * rh)
                small.getPixels(px, 0, rw, 0, 0, rw, rh)
                val r = slideXY(px, rw, rh, t, 24, 24)
                if (r[0] < out[i] || out[i] >= 99f) out[i] = r[0]
                if (r[0] < thr[i]) {
                    found = true
                    gX[i] = (x0 + (r[1] + 12f) / f) / b.width
                    gY[i] = (y0 + (r[2] + 12f) / f) / b.height
                }
            }
        }
    }

    // Basmadan önce / sonra: sol üstte yeni çıkan ikonu bul (her yerleşimde çalışır)
    private fun diffLearnG(a: Bitmap, b: Bitmap): GL? {
        if (a.width != b.width || a.height != b.height) return null
        val H = b.height
        val W = b.width
        val cell = (H / 60).coerceAtLeast(8)
        val rx1 = (0.40f * W).toInt()
        val ry1 = (0.34f * H).toInt()
        val gw = rx1 / cell + 1
        val gh = ry1 / cell + 1
        val cnt = IntArray(gw * gh)
        val minXs = IntArray(gw * gh) { Int.MAX_VALUE }
        val maxXs = IntArray(gw * gh) { -1 }
        val minYs = IntArray(gw * gh) { Int.MAX_VALUE }
        val maxYs = IntArray(gw * gh) { -1 }
        var y = 0
        while (y < ry1) {
            var x = 0
            while (x < rx1) {
                val p = a.getPixel(x, y)
                val q = b.getPixel(x, y)
                val d = abs(((p shr 16) and 255) - ((q shr 16) and 255)) +
                    abs(((p shr 8) and 255) - ((q shr 8) and 255)) +
                    abs((p and 255) - (q and 255))
                if (d > 90) {
                    val k = (y / cell) * gw + x / cell
                    cnt[k]++
                    if (x < minXs[k]) minXs[k] = x
                    if (x > maxXs[k]) maxXs[k] = x
                    if (y < minYs[k]) minYs[k] = y
                    if (y > maxYs[k]) maxYs[k] = y
                }
                x += 2
            }
            y += 2
        }
        val seen = BooleanArray(gw * gh)
        var bestTot = 0
        var bx0 = 0
        var bx1 = 0
        var by0 = 0
        var by1 = 0
        for (st in 0 until gw * gh) {
            if (seen[st] || cnt[st] < 4) continue
            val stack = ArrayList<Int>()
            stack.add(st)
            seen[st] = true
            var tot = 0
            var mnx = Int.MAX_VALUE
            var mxx = -1
            var mny = Int.MAX_VALUE
            var mxy = -1
            while (stack.isNotEmpty()) {
                val k = stack.removeAt(stack.size - 1)
                tot += cnt[k]
                if (minXs[k] < mnx) mnx = minXs[k]
                if (maxXs[k] > mxx) mxx = maxXs[k]
                if (minYs[k] < mny) mny = minYs[k]
                if (maxYs[k] > mxy) mxy = maxYs[k]
                val kx = k % gw
                val ky = k / gw
                for (d in 0 until 4) {
                    val nx = kx + (if (d == 0) 1 else if (d == 1) -1 else 0)
                    val ny = ky + (if (d == 2) 1 else if (d == 3) -1 else 0)
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val nk = ny * gw + nx
                    if (!seen[nk] && cnt[nk] >= 4) {
                        seen[nk] = true
                        stack.add(nk)
                    }
                }
            }
            val bw = mxx - mnx + 1
            val bh = mxy - mny + 1
            if (bw < 0.02f * H || bh < 0.02f * H || bw > 0.09f * H || bh > 0.09f * H) continue
            if (bw > bh * 1.5f || bh > bw * 1.5f) continue
            if (tot > bestTot) {
                bestTot = tot
                bx0 = mnx
                bx1 = mxx
                by0 = mny
                by1 = mxy
            }
        }
        if (bestTot < 12) return null
        val sz = maxOf(bx1 - bx0 + 1, by1 - by0 + 1)
        val cx = (bx0 + bx1) / 2
        val cy = (by0 + by1) / 2
        val x0 = (cx - sz / 2).coerceIn(0, W - sz)
        val y0 = (cy - sz / 2).coerceIn(0, H - sz)
        val crop = Bitmap.createBitmap(b, x0, y0, sz, sz)
        val small = Bitmap.createScaledBitmap(crop, 24, 24, true)
        val px = IntArray(24 * 24)
        small.getPixels(px, 0, 24, 0, 0, 24, 24)
        val bytes = ByteArray(px.size * 3)
        for (i in px.indices) {
            bytes[i * 3] = ((px[i] shr 16) and 255).toByte()
            bytes[i * 3 + 1] = ((px[i] shr 8) and 255).toByte()
            bytes[i * 3 + 2] = (px[i] and 255).toByte()
        }
        return GL(Base64.encodeToString(bytes, Base64.NO_WRAP), sz.toFloat() / H, (x0 + sz / 2f) / W, (y0 + sz / 2f) / H)
    }

    // Katalogdaki beceri ikonunu ekranın sağ-alt bölgesinde ara: [x, y, skor, boyut oranı]
    private fun findSlot(b: Bitmap, q64: String): FloatArray? {
        val bytes = Base64.decode(q64, Base64.DEFAULT)
        val qb = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val qw = qb.width / 2
        val kk = 4
        val x0 = (b.width * 0.40f).toInt()
        val y0 = (b.height * 0.30f).toInt()
        val rw = (b.width - x0) / kk
        val rh = (b.height - y0) / kk
        if (rw < 40 || rh < 40) return null
        val reg = Bitmap.createBitmap(b, x0, y0, b.width - x0, b.height - y0)
        val small = Bitmap.createScaledBitmap(reg, rw, rh, true)
        val px = IntArray(rw * rh)
        small.getPixels(px, 0, rw, 0, 0, rw, rh)
        val g = IntArray(rw * rh)
        for (i in px.indices) {
            val c = px[i]
            g[i] = (((c shr 16) and 255) * 30 + ((c shr 8) and 255) * 59 + (c and 255) * 11) / 100
        }
        val iw = rw + 1
        val sm = LongArray(iw * (rh + 1))
        val sq = LongArray(iw * (rh + 1))
        for (y in 0 until rh) {
            var rs = 0L
            var rq = 0L
            for (x in 0 until rw) {
                val v = g[y * rw + x]
                rs += v
                rq += v * v
                sm[(y + 1) * iw + x + 1] = sm[y * iw + x + 1] + rs
                sq[(y + 1) * iw + x + 1] = sq[y * iw + x + 1] + rq
            }
        }
        val vars = arrayOf(intArrayOf(0, 0), intArrayOf(qw, 0), intArrayOf(0, qw))
        val sizes = intArrayOf(10, 12, 14, 17, 20, 24, 28)
        var bestN = -2f
        var bestX = 0
        var bestY = 0
        var bestS = 0
        val inner = (qw * 0.6f).toInt()
        val off = (qw * 0.2f).toInt()
        for (v in vars) {
            val glyph = Bitmap.createBitmap(qb, v[0] + off, v[1] + off, inner, inner)
            for (sz in sizes) {
                if (sz >= rw || sz >= rh) continue
                val tb = Bitmap.createScaledBitmap(glyph, sz, sz, true)
                val tp = IntArray(sz * sz)
                tb.getPixels(tp, 0, sz, 0, 0, sz, sz)
                val n = sz * sz
                val tg = FloatArray(n)
                var mean = 0f
                for (i in 0 until n) {
                    val c = tp[i]
                    tg[i] = (((c shr 16) and 255) * 30 + ((c shr 8) and 255) * 59 + (c and 255) * 11) / 100f
                    mean += tg[i]
                }
                mean /= n
                var vr = 0f
                for (i in 0 until n) {
                    tg[i] -= mean
                    vr += tg[i] * tg[i]
                }
                val sd = Math.sqrt((vr / n).toDouble()).toFloat()
                if (sd < 4f) continue
                for (i in 0 until n) tg[i] /= sd
                var y = 0
                while (y <= rh - sz) {
                    var x = 0
                    while (x <= rw - sz) {
                        val a = (y + sz) * iw + x + sz
                        val bb = y * iw + x + sz
                        val cc = (y + sz) * iw + x
                        val dd = y * iw + x
                        val ws = (sm[a] - sm[bb] - sm[cc] + sm[dd]).toFloat()
                        val wq = (sq[a] - sq[bb] - sq[cc] + sq[dd]).toFloat()
                        val wm = ws / n
                        val wv = wq / n - wm * wm
                        if (wv > 36f) {
                            var dot = 0f
                            var ti = 0
                            var yy = 0
                            while (yy < sz) {
                                var p = (y + yy) * rw + x
                                var xx = 0
                                while (xx < sz) {
                                    dot += tg[ti] * g[p]
                                    ti++
                                    p++
                                    xx++
                                }
                                yy++
                            }
                            val ncc = (dot - wm * 0f) / (n * Math.sqrt(wv.toDouble()).toFloat())
                            if (ncc > bestN) {
                                bestN = ncc
                                bestX = x
                                bestY = y
                                bestS = sz
                            }
                        }
                        x += 2
                    }
                    y += 2
                }
            }
        }
        if (bestN < 0.42f || bestS == 0) return null
        val cx = x0 + (bestX + bestS / 2f) * kk
        val cy = y0 + (bestY + bestS / 2f) * kk
        return floatArrayOf(cx / b.width, cy / b.height, bestN, bestS * kk / b.height.toFloat())
    }

    // Düğmenin çevresi basmadan önce / sonra ne kadar değişti
    private fun slotChange(a: Bitmap, b: Bitmap, fx: Float, fy: Float, szf: Float): Float {
        if (a.width != b.width || a.height != b.height) return 0f
        val r = (szf * a.height * 0.7f).toInt().coerceAtLeast(10)
        val cx = (fx * a.width).toInt()
        val cy = (fy * a.height).toInt()
        val x0 = (cx - r).coerceAtLeast(0)
        val y0 = (cy - r).coerceAtLeast(0)
        val x1 = (cx + r).coerceAtMost(a.width - 1)
        val y1 = (cy + r).coerceAtMost(a.height - 1)
        var sum = 0L
        var n = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val p = a.getPixel(x, y)
                val q = b.getPixel(x, y)
                sum += abs(((p shr 16) and 255) - ((q shr 16) and 255)) +
                    abs(((p shr 8) and 255) - ((q shr 8) and 255)) +
                    abs((p and 255) - (q and 255))
                n++
                x += 3
            }
            y += 3
        }
        return if (n == 0) 0f else sum.toFloat() / (n * 3)
    }

    // "Burdan yeniden başla" yazısının şablonu (çeyrek ölçek, 48x14)
    private fun cropRv(b: Bitmap, fx: Float, fy: Float): String? {
        val sc = b.height / 1080f
        val w = (RVW * 4 * sc).toInt()
        val h = (RVH * 4 * sc).toInt()
        if (w < 8 || h < 4 || w > b.width || h > b.height) return null
        val cx = (fx * b.width).toInt()
        val cy = (fy * b.height).toInt()
        val x0 = (cx - w / 2).coerceIn(0, b.width - w)
        val y0 = (cy - h / 2).coerceIn(0, b.height - h)
        val crop = Bitmap.createBitmap(b, x0, y0, w, h)
        val small = Bitmap.createScaledBitmap(crop, RVW, RVH, true)
        val px = IntArray(RVW * RVH)
        small.getPixels(px, 0, RVW, 0, 0, RVW, RVH)
        val bytes = ByteArray(px.size * 3)
        for (i in px.indices) {
            bytes[i * 3] = ((px[i] shr 16) and 255).toByte()
            bytes[i * 3 + 1] = ((px[i] shr 8) and 255).toByte()
            bytes[i * 3 + 2] = (px[i] and 255).toByte()
        }
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun analyzeRevive(b: Bitmap, t: IntArray, fx: Float, fy: Float): Float {
        if (fx < 0f || t.size < RVW * RVH * 3) return 99f
        val sc = b.height / 1080f
        val cx = (fx * b.width).toInt()
        val cy = (fy * b.height).toInt()
        val x0 = (cx - 0.22f * b.width).toInt().coerceAtLeast(0)
        val y0 = (cy - 0.12f * b.height).toInt().coerceAtLeast(0)
        val x1 = (cx + 0.22f * b.width).toInt().coerceAtMost(b.width)
        val y1 = (cy + 0.12f * b.height).toInt().coerceAtMost(b.height)
        val f = 0.25f / sc
        val rw = ((x1 - x0) * f).toInt()
        val rh = ((y1 - y0) * f).toInt()
        if (rw < RVW + 2 || rh < RVH + 2) return 99f
        val reg = Bitmap.createBitmap(b, x0, y0, x1 - x0, y1 - y0)
        val small = Bitmap.createScaledBitmap(reg, rw, rh, true)
        val px = IntArray(rw * rh)
        small.getPixels(px, 0, rw, 0, 0, rw, rh)
        return slide(px, rw, rh, t, RVW, RVH)
    }

    private fun learnRevive() {
        val pk = "p" + profile + "_"
        pickPoint("Ölüyken: Burdan yeniden başla yazısına dokun") { fx, fy ->
            runShot(false, fx, fy, false, { a, _ ->
                val t = cropRv(a, fx, fy)
                if (t != null) {
                    prefs.edit().putString(pk + "rvt", t).putFloat(pk + "rvx", fx).putFloat(pk + "rvy", fy).commit()
                    true
                } else {
                    false
                }
            }, "Yazı öğrenildi", "Öğrenilemedi, tekrar dene")
        }
    }

    private fun applyHand(hs: FloatArray) {
        hState = if (minOf(hs[0], hs[1]) > 40f) 0
        else if (hs[0] < hs[1] - 3f) 1
        else if (hs[1] < hs[0] - 3f) 2
        else hState
    }

    private fun applyRevive(rv: Float) {
        if (rv >= 24f || rvFx < 0f || !running) return
        val now = SystemClock.elapsedRealtime()
        restUntil = now + rvWait * 1000L
        if (now - rvLastTap > 1400L) {
            tapFrac(rvFx, rvFy)
            rvLastTap = now
            rvCount++
        }
    }

    // Beceri ikonunu ekranda bulur, yuvayı kaydeder, basıp dener
    private fun autoFind(i: Int) {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Android 11 veya üstü gerekli")
            return
        }
        if (autoBusy) return
        autoBusy = true
        val pf = profile
        val kk = "s" + pf + "_" + i + "_"
        val q = Cfg.SICON[pf][i]
        val nm = Cfg.SNAME[pf][i]
        showMenu(false)
        panel?.visibility = View.INVISIBLE
        toast(nm + " aranıyor...")
        fun finish(msg: String) {
            autoBusy = false
            panel?.visibility = if (inGame) View.VISIBLE else View.GONE
            showMenu(true)
            toast(msg)
        }
        handler.postDelayed({
            grab { a ->
                if (a == null) {
                    handler.post { finish("Ekran görüntüsü alınamadı") }
                } else {
                    var r: FloatArray? = null
                    try {
                        r = findSlot(a, q)
                    } catch (ex: Exception) {
                    }
                    if (r == null) {
                        handler.post { finish(nm + " ekranda bulunamadı. Oyundayken dene ya da Elle göster") }
                    } else {
                        val fx = r[0]
                        val fy = r[1]
                        val szf = r[3]
                        prefs.edit().putFloat(kk + "x", fx).putFloat(kk + "y", fy).commit()
                        handler.post {
                            tapFrac(fx, fy)
                            handler.postDelayed({
                                grab { b ->
                                    val ch = if (b != null) slotChange(a, b, fx, fy, szf) else 0f
                                    handler.post {
                                        finish(if (ch > 8f) nm + ": yuva bulundu, basınca düğme değişti (çalışıyor)"
                                        else nm + ": yuva bulundu, basıldı ama değişim görülmedi")
                                    }
                                }
                            }, 700L)
                        }
                    }
                }
            }
        }, 600L)
    }

    private fun learnOne(key: String, fx: Float, fy: Float, label: String) {
        runShot(false, fx, fy, false, { a, _ ->
            val t = cropTpl(a, fx, fy)
            if (t != null) {
                prefs.edit().putString(key, t).commit()
                true
            } else {
                false
            }
        }, label + " öğrenildi", "Öğrenilemedi")
    }

    private fun scan() {
        if (autoBusy) return
        val now = SystemClock.elapsedRealtime()
        if (busy && now - busySince > 3000L) busy = false
        if (busy) return
        busy = true
        busySince = now
        val tpls = tplBuff
        val sm = smode.copyOf()
        val sxs = bx.copyOf()
        val sys = by.copyOf()
        val tps = sTplP.copyOf()
        val tas = sTplA.copyOf()
        val nxx = nX
        val nyy = nY
        val ntp = nTplP
        val nta = nTplA
        val nm = nMode
        val mtA = mtOn && running && inGame
        val doTgt = !mtOn && nm == 2 && nisanOn && now - lastTgt >= tgtMs.toLong() && now >= restUntil
        val hm = hMode
        val hxx = hX
        val hyy = hY
        val hpp = hTplP
        val haa = hTplA
        val rvA = rvOn && running
        val rvTT = rvT
        val rvx = rvFx
        val rvy = rvFy
        if (doTgt) lastTgt = now
        val lp = learnPt
        val doLearn = lp != null && now >= learnAfter
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) {
                        handler.post { busy = false }
                        return
                    }
                    // Nişan önce çözülür ve hemen uygulanır, buff analizi beklemez
                    val ns = if (nm == 1) analyzeSlot(bmp, nxx, nyy, ntp, nta, 103f) else floatArrayOf(99f, 99f)
                    handler.post { applyNisan(ns, now) }
                    if (doTgt) {
                        val tg = findTarget(bmp)
                        if (tg != null) handler.post { tapFrac(tg[0], tg[1]); tgtCount++ }
                    }
                    if (hm == 1 && hpp != null && haa != null && hxx >= 0f) {
                        val hs = analyzeSlot(bmp, hxx, hyy, hpp, haa, 103f)
                        handler.post { applyHand(hs) }
                    }
                    if (rvA && rvTT != null) {
                        val rv = analyzeRevive(bmp, rvTT, rvx, rvy)
                        handler.post { applyRevive(rv) }
                    }
                    if (mtA) mtProcess(bmp)
                    val bs = analyzeBuffs(bmp, tpls)
                    analyzeBuffG(bmp, bs)
                    val sp = FloatArray(MAXS) { 99f }
                    val sa = FloatArray(MAXS) { 99f }
                    for (n in 0 until MAXS) {
                        if (sm[n] == 2 && sxs[n] >= 0f) {
                            val rr = analyzeSlot(bmp, sxs[n], sys[n], tps[n], tas[n], 80f)
                            sp[n] = rr[0]
                            sa[n] = rr[1]
                        }
                    }
                    var learned: String? = null
                    if (doLearn && lp != null) learned = learnIcon(bmp, lp[0], lp[1])
                    handler.post {
                        busy = false
                        if (learned != null) {
                            val li = learnIdx
                            prefs.edit().putString("s" + profile + "_" + li + "_t", learned).commit()
                            useTimer[li] = false
                            noSee[li] = 0
                            loadCfg()
                            learnPt = null
                            toast(Cfg.SNAME[profile][li] + " ikonu öğrenildi")
                        }
                        applyScan(bs, sp, sa)
                    }
                } catch (ex: Exception) {
                    handler.post { busy = false }
                }
            }

            override fun onFailure(code: Int) {
                handler.post { busy = false }
            }
        })
    }

    // Nişan durumunu hemen işle: pasifse bekletmeden bas
    private fun applyNisan(ns: FloatArray, shotAt: Long) {
        scoreP = ns[0]
        scoreA = ns[1]
        nisanState = if (minOf(scoreP, scoreA) > 40f) 0
        else if (scoreP < scoreA - 3f) 1
        else if (scoreA < scoreP - 3f) 2
        else 0
        nisanShotAt = shotAt
        updateStatus()
        if (running) decide(SystemClock.elapsedRealtime())
    }

    private fun applyScan(bs: FloatArray, sp: FloatArray, sa: FloatArray) {
        val now = SystemClock.elapsedRealtime()
        for (b in 0 until nSk) {
            scoreB[b] = bs[b]
            val md = smode[b]
            val tracked = (md == 1 && tplBuff[b] != null) ||
                (md == 2 && sTplP[b] != null && sTplA[b] != null && bx[b] >= 0f)
            val p: Boolean
            if (tracked && !useTimer[b]) {
                if (md == 2) {
                    // düğmenin kendi aktif / pasif görünümünü izle
                    p = if (minOf(sp[b], sa[b]) > 40f) present[b]
                    else if (sa[b] < sp[b] - 3f) true
                    else if (sp[b] < sa[b] - 3f) false
                    else present[b]
                } else {
                    // sol üstteki buff ikonunu izle
                    p = bs[b] < thr[b]
                }
                if (p) {
                    noSee[b] = 0
                    verifyAt[b] = 0L
                } else if (verifyAt[b] > 0L && now >= verifyAt[b]) {
                    // basıldı ama görünmedi: 3 kez üst üste olursa süreye geç
                    verifyAt[b] = 0L
                    noSee[b]++
                    if (noSee[b] >= 3) {
                        useTimer[b] = true
                        toast(Cfg.SNAME[profile][b] + ": takip olmadı, süreye göre yenilenecek")
                    }
                }
            } else {
                p = lastCast[b] > 0L && now - lastCast[b] < secs[b] * 1000L
            }
            present[b] = p
            if (p) miss[b] = 0 else miss[b]++
        }
        updateStatus()
        if (running) decide(now)
    }

    // ---------------- karar: görülen anda hemen bas ----------------

    private fun decide(now: Long) {
        if (!inGame) return
        if (SystemClock.elapsedRealtime() < restUntil) return
        // 1) Nişan pasif oldu: anında tekrar aç (öncelikli). Basıştan sonra çekilmiş
        //    bir görüntü pasif gösteriyorsa bas; eski görüntüyle çift basılmaz.
        if (!mtOn && nisanOn && nisanState == 1 && nisanShotAt > lastNisan + 200L && now - lastNisan > nisanGap) {
            tapFrac(nX, nY)
            lastNisan = now
            nisanCount++
            return
        }
        if (now - lastTap < 90L) return
        // 2) Bir beceri (buff) bitti: anında yenile
        if (now >= skillLock) {
            for (b in 0 until nSk) {
                if (skillOn[b] && bx[b] >= 0f && miss[b] >= 1 && now - lastCast[b] > recastGap) {
                    tapFrac(bx[b], by[b])
                    lastCast[b] = now
                    verifyAt[b] = now + 2500L
                    miss[b] = 0
                    skillLock = now + castLockMs
                    skillCount++
                    return
                }
            }
        }
    }

    // ---------------- döngüler ----------------

    // sürekli tarama (ekran görüntüsü sınırı izin verdiği kadar hızlı)
    private val scanLoop = object : Runnable {
        override fun run() {
            if (Build.VERSION.SDK_INT >= 30 && inGame) scan()
            handler.postDelayed(this, if (running) scanGap else 600L)
        }
    }

    // Kırmızı canavar ismini bulur, gövdesine denk gelen noktayı (ekran oranı) döndürür
    private fun findTarget(b: Bitmap): FloatArray? {
        val w = b.width
        val h = b.height
        val sc = h / 1080f
        val cell = (14f * sc).toInt().coerceAtLeast(6)
        val x0 = (w * 0.10f).toInt()
        val x1 = (w * 0.90f).toInt()
        val y0 = (h * 0.15f).toInt()
        val y1 = (h * 0.82f).toInt()
        val gw = (x1 - x0) / cell + 1
        val gh = (y1 - y0) / cell + 1
        val cnt = IntArray(gw * gh)
        val rw = x1 - x0
        val rh = y1 - y0
        val px = IntArray(rw)
        var y = y0
        while (y < y1) {
            b.getPixels(px, 0, rw, x0, y, rw, 1)
            for (i in 0 until rw) {
                val p = px[i]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val bl = p and 255
                if (r > 170 && g < 80 && bl < 80 && r - g > 110) {
                    cnt[((y - y0) / cell) * gw + i / cell]++
                }
            }
            y += 2
        }
        val seen = BooleanArray(gw * gh)
        var best: FloatArray? = null
        var bestD = 1e9f
        val cx = w * 0.5f
        val cy = h * 0.55f
        for (st in 0 until gw * gh) {
            if (seen[st] || cnt[st] < 3) continue
            val stack = ArrayList<Int>()
            stack.add(st)
            seen[st] = true
            var minX = gw
            var maxX = 0
            var minY = gh
            var maxY = 0
            var tot = 0
            while (stack.isNotEmpty()) {
                val k = stack.removeAt(stack.size - 1)
                val kx = k % gw
                val ky = k / gw
                if (kx < minX) minX = kx
                if (kx > maxX) maxX = kx
                if (ky < minY) minY = ky
                if (ky > maxY) maxY = ky
                tot += cnt[k]
                for (d in 0 until 4) {
                    val nx = kx + (if (d == 0) 1 else if (d == 1) -1 else 0)
                    val ny = ky + (if (d == 2) 1 else if (d == 3) -1 else 0)
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val nk = ny * gw + nx
                    if (!seen[nk] && cnt[nk] >= 3) {
                        seen[nk] = true
                        stack.add(nk)
                    }
                }
            }
            val bw = (maxX - minX + 1) * cell
            val bh = (maxY - minY + 1) * cell
            if (tot < 25 || bw < 30 * sc || bh > 50 * sc || bw < bh * 1.6f) continue
            val mx = x0 + (minX + maxX + 1) * cell / 2f
            val my = y0 + (minY + maxY + 1) * cell / 2f
            val d = (mx - cx) * (mx - cx) + (my - cy) * (my - cy)
            val rl = floatArrayOf(9f, 0.20f, 0.32f, 0.46f)[tgtRad.coerceIn(0, 3)] * h
            if (d > rl * rl) continue
            if (d < bestD) {
                bestD = d
                val off = floatArrayOf(0.05f, 0.08f, 0.11f)[tgtOff.coerceIn(0, 2)]
                best = floatArrayOf(mx / w, (my / h + off).coerceAtMost(0.95f))
            }
        }
        return best
    }

    private val atkLoop = object : Runnable {
        override fun run() {
            if (!running) return
            if (mtOn) {
                handler.postDelayed(this, 400L)
                return
            }
            val now = SystemClock.elapsedRealtime()
            var wait = atkMs.toLong()
            if (now < restUntil) {
                wait = 300L
            } else if (potOn && pX >= 0f && now - lastPot >= potSec * 1000L) {
                if (now - lastTap < 120L) {
                    wait = 60L
                } else {
                    tapFrac(pX, pY)
                    lastPot = now
                }
            } else if (aOn && aX >= 0f) {
                if (now - lastTap < 120L) {
                    wait = 60L
                } else {
                    tapFrac(aX, aY)
                }
            }
            handler.postDelayed(this, wait)
        }
    }

    private val pickLoop = object : Runnable {
        override fun run() {
            if (!running) return
            if (mtOn) {
                handler.postDelayed(this, 400L)
                return
            }
            val now = SystemClock.elapsedRealtime()
            var wait = pickMs.toLong()
            if (now < restUntil) {
                wait = 300L
            } else if (pickOn && hX >= 0f) {
                if (hMode == 1 && hTplP != null && hTplA != null) {
                    wait = 150L
                    if (hState == 1 && now - lastTap >= 120L && now - lastHandTap > 900L) {
                        tapFrac(hX, hY)
                        lastHandTap = now
                        pickCount++
                    }
                } else if (now - lastTap < 120L) {
                    wait = 60L
                } else {
                    tapFrac(hX, hY)
                    pickCount++
                }
            }
            handler.postDelayed(this, wait)
        }
    }

    // Hangi uygulama önde? Sadece seçili oyundaysa pencereyi göster ve çalış.
    private fun topAppPkg(): String? {
        try {
            val ws = windows
            if (ws == null || ws.isEmpty()) return null
            var best: AccessibilityWindowInfo? = null
            for (wi in ws) {
                if (wi.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                if (wi.isActive) {
                    best = wi
                    break
                }
                if (best == null || wi.layer > best.layer) best = wi
            }
            val root = best?.root ?: return null
            return root.packageName?.toString()
        } catch (ex: Exception) {
            return null
        }
    }

    // Pencere yeniden eklenmesi gerekirse (sistem kaldırdıysa) geri ekle
    private fun ensurePanel() {
        val v = panel ?: return
        val w = wm ?: return
        val lp = panelLp ?: return
        if (!v.isAttachedToWindow) {
            try {
                w.addView(v, lp)
            } catch (ex: Exception) {
            }
        }
    }

    private val gameLoop = object : Runnable {
        override fun run() {
            for (x in 0 until Cfg.GNAME.size) {
                gamePkgs[x] = prefs.getString("gp_" + x, "") ?: ""
            }
            val pkg = topAppPkg() ?: evPkg
            var g = -1
            for (x in 0 until Cfg.GNAME.size) {
                if (gamePkgs[x].isNotEmpty() && pkg == gamePkgs[x]) g = x
            }
            val here = g >= 0
            if (here) outCount = 0 else if (outCount < 100) outCount++
            // Oyundan çıkış: üst üste 2 kontrolde (~1,2 sn) oyun görünmezse gizle
            val target = if (here) true else if (outCount >= 2) false else inGame
            if (here && g != curGame) {
                // oyun değişti: o oyunun son karakterine geç
                curGame = g
                panelLogo?.setImageResource(logoRes(g))
                if (Cfg.PGAME[profile] != g) {
                    stopAll()
                    var np = prefs.getInt("lastp_" + g, firstProfile(g))
                    if (np < 0 || np >= Cfg.PGAME.size || Cfg.PGAME[np] != g) np = firstProfile(g)
                    prefs.edit().putInt("profile", np).commit()
                    showMenu(false)
                    loadCfg()
                }
            }
            if (target != inGame) {
                inGame = target
                if (target) {
                    ensurePanel()
                    panel?.visibility = View.VISIBLE
                    loadCfg()
                    updateStatus()
                    if (resumeAfter) {
                        resumeAfter = false
                        handler.postDelayed({
                            if (inGame && !running) toggle()
                        }, 1200L)
                    }
                } else {
                    resumeAfter = running
                    panel?.visibility = View.GONE
                    stopAll()
                    showMenu(false)
                    learnPt = null
                }
            } else if (inGame) {
                ensurePanel()
            }
            handler.postDelayed(this, 600L)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            val s = (SystemClock.elapsedRealtime() - startAt) / 1000
            updateStats()
            timeText?.text = "%s %02d:%02d · N%d B%d T%d H%d".format(pname(), s / 60, s % 60, nisanCount, skillCount, pickCount, tgtCount)
            handler.postDelayed(this, 1000)
        }
    }

    private fun updateStatus() {
        for (n in 0 until panelIcons.size) {
            val idx = panelIdx[n]
            val on = if (idx >= 0) present[idx] else if (idx == -1) (nisanState == 2) else running
            panelIcons[n].alpha = if (on) 1f else 0.35f
        }
    }

    private fun stopAll() {
        running = false
        mtStop()
        handler.removeCallbacks(pickLoop)
        handler.removeCallbacks(atkLoop)
        handler.removeCallbacks(ticker)
        setRunIcon(false)
        timeText?.text = pname()
    }

    fun toggle() {
        if (running) {
            stopAll()
            return
        }
        if (prefs.getLong("unlock_until", 0L) < System.currentTimeMillis()) {
            toast("Önce Oto Av uygulamasını açıp şifreyi gir")
            return
        }
        if (Build.VERSION.SDK_INT < 30) {
            toast("Android 11 veya üstü gerekli")
            return
        }
        if (!inGame) {
            toast("Önce seçili oyuna gir")
            return
        }
        loadCfg()
        running = true
        nisanCount = 0
        skillCount = 0
        pickCount = 0
        tgtCount = 0
        lastTgt = 0L
        restUntil = 0L
        hState = 0
        mtReset()
        lastPot = 0L
        lastNisan = 0L
        skillLock = 0L
        for (b in 0 until MAXS) {
            miss[b] = 0
            lastCast[b] = 0L
            useTimer[b] = false
            noSee[b] = 0
            verifyAt[b] = 0L
        }
        startAt = SystemClock.elapsedRealtime()
        setRunIcon(true)
        handler.post(pickLoop)
        handler.post(atkLoop)
        handler.post(ticker)
        scan()
    }

    // ---------------- arayüz yardımcıları ----------------

    // ---------------- çizilen ikonlar (emoji yok) ----------------
    private val symCache = HashMap<String, BitmapDrawable>()

    private fun sym(kind: String, color: Int): BitmapDrawable {
        val key = kind + "#" + color
        val got = symCache[key]
        if (got != null) return got
        val n = 96
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = n / 24f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        val f = Paint(Paint.ANTI_ALIAS_FLAG)
        f.color = color
        f.style = Paint.Style.FILL
        val pa = Path()
        fun ln(a: Float, b: Float, c2: Float, d: Float) {
            c.drawLine(a * s, b * s, c2 * s, d * s, p)
        }
        when (kind) {
            "play" -> {
                pa.moveTo(7f * s, 4f * s)
                pa.lineTo(20f * s, 12f * s)
                pa.lineTo(7f * s, 20f * s)
                pa.close()
                c.drawPath(pa, f)
            }
            "stop" -> c.drawRoundRect(RectF(6f * s, 6f * s, 18f * s, 18f * s), 2f * s, 2f * s, f)
            "menu" -> {
                ln(4f, 7f, 20f, 7f)
                ln(4f, 12f, 20f, 12f)
                ln(4f, 17f, 20f, 17f)
            }
            "close" -> {
                ln(6f, 6f, 18f, 18f)
                ln(18f, 6f, 6f, 18f)
            }
            "plus" -> {
                ln(12f, 5f, 12f, 19f)
                ln(5f, 12f, 19f, 12f)
            }
            "minus" -> ln(5f, 12f, 19f, 12f)
            "tgt" -> {
                c.drawCircle(12f * s, 12f * s, 7f * s, p)
                c.drawCircle(12f * s, 12f * s, 1.5f * s, f)
                ln(12f, 2f, 12f, 6f)
                ln(12f, 18f, 12f, 22f)
                ln(2f, 12f, 6f, 12f)
                ln(18f, 12f, 22f, 12f)
            }
            "sword" -> {
                ln(6f, 18f, 19f, 5f)
                ln(8f, 12f, 12f, 16f)
                ln(6f, 18f, 4f, 20f)
            }
            "hand" -> {
                c.drawRoundRect(RectF(7f * s, 11f * s, 18f * s, 21f * s), 3f * s, 3f * s, p)
                ln(9f, 11f, 9f, 5f)
                ln(11.5f, 11f, 11.5f, 4f)
                ln(14f, 11f, 14f, 5f)
                ln(16.5f, 11f, 16.5f, 7f)
            }
            "pot" -> {
                ln(9.5f, 3f, 14.5f, 3f)
                pa.moveTo(10f * s, 3f * s)
                pa.lineTo(10f * s, 9f * s)
                pa.lineTo(5.5f * s, 18f * s)
                pa.quadTo(5f * s, 21f * s, 8f * s, 21f * s)
                pa.lineTo(16f * s, 21f * s)
                pa.quadTo(19f * s, 21f * s, 18.5f * s, 18f * s)
                pa.lineTo(14f * s, 9f * s)
                pa.lineTo(14f * s, 3f * s)
                c.drawPath(pa, p)
                ln(7.5f, 15f, 16.5f, 15f)
            }
            "heart" -> {
                pa.moveTo(12f * s, 20f * s)
                pa.cubicTo(3f * s, 14f * s, 3f * s, 6f * s, 8.5f * s, 6f * s)
                pa.cubicTo(10.5f * s, 6f * s, 12f * s, 7.5f * s, 12f * s, 9f * s)
                pa.cubicTo(12f * s, 7.5f * s, 13.5f * s, 6f * s, 15.5f * s, 6f * s)
                pa.cubicTo(21f * s, 6f * s, 21f * s, 14f * s, 12f * s, 20f * s)
                pa.close()
                c.drawPath(pa, p)
            }
            "star" -> {
                for (k in 0 until 10) {
                    val ang = Math.toRadians((-90 + k * 36).toDouble())
                    val r = if (k % 2 == 0) 9f else 4f
                    val x = (12f + r * Math.cos(ang).toFloat()) * s
                    val y = (12f + r * Math.sin(ang).toFloat()) * s
                    if (k == 0) pa.moveTo(x, y) else pa.lineTo(x, y)
                }
                pa.close()
                c.drawPath(pa, p)
            }
            "gear" -> {
                c.drawCircle(12f * s, 12f * s, 3.2f * s, p)
                for (k in 0 until 8) {
                    val ang = Math.toRadians((k * 45).toDouble())
                    val ca = Math.cos(ang).toFloat()
                    val sa = Math.sin(ang).toFloat()
                    ln(12f + 6.5f * ca, 12f + 6.5f * sa, 12f + 9.5f * ca, 12f + 9.5f * sa)
                }
                c.drawCircle(12f * s, 12f * s, 6.5f * s, p)
            }
            "bolt" -> {
                c.drawArc(RectF(3f * s, 5f * s, 21f * s, 23f * s), 180f, 180f, false, p)
                ln(12f, 14f, 16f, 9f)
            }
        }
        val d = BitmapDrawable(resources, bmp)
        d.setFilterBitmap(true)
        symCache[key] = d
        return d
    }

    private fun symBtn(kind: String, padPx: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageDrawable(sym(kind, cText))
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.setPadding(padPx, padPx, padPx, padPx)
        v.background = shape(cStone, cStroke, 8, 1)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun setRunIcon(on: Boolean) {
        startBtn?.setImageDrawable(sym(if (on) "stop" else "play", cText))
        menuRun?.text = if (on) "Durdur" else "Başlat"
        updateStats()
    }

    private fun dpx(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, stroke: Int, rDp: Int, strokeDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dpx(rDp).toFloat()
        if (strokeDp > 0) g.setStroke(dpx(strokeDp), stroke)
        return g
    }

    // taş görünümlü düğme (koyu zemin, mavi kenar)
    private fun stoneBtn(label: String, sp: Float, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = sp
        t.setTextColor(cText)
        t.gravity = Gravity.CENTER
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.background = shape(cStone, cStroke, 8, 1)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun styledSwitch(label: String, init: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        sw.text = label
        sw.setTextColor(cText)
        sw.textSize = 13f
        sw.isChecked = init
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(cAccent, 0xFF6C86A8.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x6638C6FF, 0x44FFFFFF))
        sw.setPadding(0, dpx(5), 0, dpx(5))
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        return sw
    }

    private fun sectionHead(t: String): TextView {
        val h = TextView(this)
        h.text = t
        h.textSize = 12f
        h.setTypeface(h.typeface, Typeface.BOLD)
        h.setTextColor(cCyan)
        h.setPadding(0, dpx(10), 0, dpx(2))
        return h
    }

    private fun drag(handle: View, target: View, lp: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        handle.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                sx = e.rawX
                sy = e.rawY
                ox = lp.x
                oy = lp.y
            } else if (e.action == MotionEvent.ACTION_MOVE) {
                lp.x = ox + (e.rawX - sx).toInt()
                lp.y = oy + (e.rawY - sy).toInt()
                try {
                    wm?.updateViewLayout(target, lp)
                } catch (ex: Exception) {
                }
            }
            true
        }
    }

    private fun testRow(a: String, fa: () -> Unit, b: String, fb: () -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val ba = stoneBtn(a, 12f, fa)
        val bb = stoneBtn(b, 12f, fb)
        val p1 = LinearLayout.LayoutParams(0, dpx(40), 1f)
        p1.topMargin = dpx(4)
        p1.rightMargin = dpx(3)
        val p2 = LinearLayout.LayoutParams(0, dpx(40), 1f)
        p2.topMargin = dpx(4)
        p2.leftMargin = dpx(3)
        row.addView(ba, p1)
        row.addView(bb, p2)
        return row
    }

    // Tam ekran dokunma katmanı: dokunulan noktayı ekran oranı olarak verir
    private fun pickPoint(msg: String, done: (Float, Float) -> Unit) {
        val w = wm ?: return
        showMenu(false)
        val v = FrameLayout(this)
        v.setBackgroundColor(0x99000000.toInt())
        val tv = TextView(this)
        tv.text = msg
        tv.textSize = 18f
        tv.setTextColor(cText)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dpx(16), dpx(10), dpx(16), dpx(10))
        tv.background = glass(12)
        v.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val sc = screen()
                val fx = (e.rawX / sc[0]).coerceIn(0f, 1f)
                val fy = (e.rawY / sc[1]).coerceIn(0f, 1f)
                removeSafe(v)
                handler.post {
                    done(fx, fy)
                    showMenu(true)
                }
            }
            true
        }
        w.addView(v, lp)
    }

    // ---------------- kontrol menüsü ----------------

    private fun btnRow(items: List<Pair<String, () -> Unit>>): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (it in items) {
            val b = stoneBtn(it.first, 11f, it.second)
            val p = LinearLayout.LayoutParams(0, dpx(36), 1f)
            p.topMargin = dpx(4)
            p.leftMargin = dpx(2)
            p.rightMargin = dpx(2)
            row.addView(b, p)
        }
        return row
    }

    private fun slotText(x: Float): String = if (x >= 0f) "Yuva: ayarlı" else "Yuva: ayarlanmadı"

    private fun skillInfo(i: Int): String {
        val t = if (smode[i] == 2) {
            if (sTplP[i] != null && sTplA[i] != null) "düğme aktif / pasif izleniyor"
            else "düğme görünümü öğrenilmedi, her " + secs[i] + " sn yeniler"
        } else if (smode[i] == 1) {
            if (tplBuff[i] == null) "ikon öğrenilmedi, her " + secs[i] + " sn yeniler"
            else if (useTimer[i]) "ikon görünmedi, her " + secs[i] + " sn yeniler"
            else "ikon öğrenildi, sol üstte izleniyor"
        } else {
            "takip yok, her " + secs[i] + " sn yeniler"
        }
        return slotText(bx[i]) + "  ·  " + t
    }

    private fun nisanInfo(): String {
        val t = if (nMode == 0) "takip yok (otomatik basmaz)"
        else if (nMode == 2) "oto hedef: kırmızı canavar ismini bulup dokunur"
        else if (nTplP != null && nTplA != null) "aktif / pasif izleniyor"
        else "görünüm öğrenilmedi"
        return slotText(nX) + "  ·  " + t
    }

    private fun cardBg(on: Boolean): GradientDrawable =
        if (on) shape(0xFF0F2A4F.toInt(), cAccent, 8, 2) else shape(0xFF081426.toInt(), 0xFF1C3A63.toInt(), 8, 1)

    private fun cardLp(): LinearLayout.LayoutParams {
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = dpx(6)
        return cp
    }

    private fun iconSwitch(ic: Drawable, label: String, init: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(this)
        img.setImageDrawable(ic)
        img.alpha = if (init) 1f else 0.35f
        row.addView(img, LinearLayout.LayoutParams(dpx(34), dpx(34)))
        val sw = styledSwitch(label, init) { on ->
            img.alpha = if (on) 1f else 0.35f
            onChange(on)
        }
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.leftMargin = dpx(8)
        row.addView(sw, p)
        return row
    }

    // Seçenek şeridi: biri seçili görünür, dokununca onSel(sıra) çağrılır
    private fun chips(labels: List<String>, sel: Int, onSel: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (n in 0 until labels.size) {
            val on = (n == sel)
            val t = TextView(this)
            t.text = labels[n]
            t.textSize = 11f
            t.gravity = Gravity.CENTER
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(if (on) 0xFF081426.toInt() else cText)
            t.background = if (on) shape(cAccent, 0xFF38C6FF.toInt(), 8, 1) else shape(cStone, cStroke, 8, 1)
            t.setOnClickListener { onSel(n) }
            val p = LinearLayout.LayoutParams(0, dpx(34), 1f)
            p.topMargin = dpx(4)
            p.leftMargin = dpx(2)
            p.rightMargin = dpx(2)
            row.addView(t, p)
        }
        return row
    }

    // Menüyü kaydırma konumunu koruyarak yeniden kur
    private fun refreshMenu() {
        lastScroll = menuSv?.scrollY ?: 0
        showMenu(false)
        showMenu(true)
    }

    private fun switchProfile(k: Int) {
        if (profile == k) return
        stopAll()
        learnPt = null
        prefs.edit().putInt("profile", k).putInt("lastp_" + Cfg.PGAME[k], k).commit()
        lastScroll = 0
        showMenu(false)
        loadCfg()
        showMenu(true)
    }

    private fun pAlpha(): Float = prefs.getFloat("palpha", 1f).coerceIn(0.3f, 1f)

    // Yüzen pencereyi yeni boyutla baştan kur; menü açıksa tekrar aç
    private fun rebuildPanel() {
        val wasMenu = menuShown
        onServiceConnected()
        panel?.visibility = if (inGame) View.VISIBLE else View.GONE
        setRunIcon(running)
        updateStatus()
        if (wasMenu) showMenu(true)
    }

    private fun addWindowCard(col: LinearLayout) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(false)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))

        val sl = TextView(this)
        sl.textSize = 12f
        sl.setTextColor(cText)
        sl.text = "Pencere boyutu: %" + (pScale * 100f + 0.5f).toInt()
        card.addView(sl)
        val sb = SeekBar(this)
        sb.max = 10
        sb.progress = ((pScale - 0.6f) * 10f + 0.5f).toInt().coerceIn(0, 10)
        sb.progressTintList = ColorStateList.valueOf(cAccent)
        sb.thumbTintList = ColorStateList.valueOf(cCyan)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                sl.text = "Pencere boyutu: %" + (60 + p * 10)
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {
                val v = 0.6f + (bar?.progress ?: 4) * 0.1f
                prefs.edit().putFloat("pscale", v).commit()
                lastScroll = menuSv?.scrollY ?: 0
                rebuildPanel()
            }
        })
        card.addView(sb)

        val tl = TextView(this)
        tl.textSize = 12f
        tl.setTextColor(cText)
        tl.setPadding(0, dpx(6), 0, 0)
        val tp0 = ((1f - pAlpha()) * 100f + 0.5f).toInt()
        tl.text = "Pencere şeffaflığı: %" + tp0
        card.addView(tl)
        val tb = SeekBar(this)
        tb.max = 7
        tb.progress = (tp0 / 10).coerceIn(0, 7)
        tb.progressTintList = ColorStateList.valueOf(cAccent)
        tb.thumbTintList = ColorStateList.valueOf(cCyan)
        tb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                tl.text = "Pencere şeffaflığı: %" + (p * 10)
                val a = 1f - p * 0.1f
                panel?.alpha = a
                prefs.edit().putFloat("palpha", a).commit()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        card.addView(tb)

        card.addView(btnRow(listOf(
            Pair("Varsayılan boyut ve şeffaflık", {
                prefs.edit().remove("pscale").remove("palpha").commit()
                lastScroll = menuSv?.scrollY ?: 0
                rebuildPanel()
            })
        )))
        col.addView(card, cardLp())
    }


    private fun addNisanCard(col: LinearLayout) {
        val pf = profile
        val pk = "p" + pf + "_"
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(nisanOn)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        card.addView(iconSwitch(iconOf(Cfg.IC_NISAN), "Hedef / Nişan", nisanOn) { on ->
            nisanOn = on
            prefs.edit().putBoolean(pk + "nisan", on).commit()
            card.background = cardBg(on)
            rebuildPanelIcons()
        })
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = nisanInfo()
        card.addView(info)
        card.addView(btnRow(listOf(
            Pair("Yuva ayarla", {
                pickPoint("Nişan düğmesine dokun") { fx, fy ->
                    prefs.edit().putFloat(pk + "nx", fx).putFloat(pk + "ny", fy).commit()
                    nX = fx
                    nY = fy
                    toast("Yuva kaydedildi")
                    rebuildPanelIcons()
                }
            }),
            Pair("Dene", {
                if (nX < 0f) {
                    toast("Önce yuvayı ayarla")
                } else {
                    tapFrac(nX, nY)
                    toast("Nişan düğmesine basıldı")
                }
            })
        )))
        card.addView(chips(listOf("Takip yok", "Aktif / pasif izle", "Oto hedef"), nMode) { n ->
            prefs.edit().putInt(pk + "nmode", n).commit()
            refreshMenu()
        })
        if (nMode == 2) {
            card.addView(btnRow(listOf(
                Pair("Hedef dene", {
                    grab { bmp ->
                        handler.post {
                            val t = if (bmp != null) findTarget(bmp) else null
                            if (bmp == null) {
                                toast("Ekran alınamadı")
                            } else if (t == null) {
                                toast("Kırmızı canavar ismi bulunamadı")
                            } else {
                                tapFrac(t[0], t[1])
                                toast("Hedef bulundu, dokunuldu")
                            }
                        }
                    }
                })
            )))
            val tl = TextView(this)
            tl.textSize = 11f
            tl.setTextColor(cText)
            tl.text = "Hedef arama sıklığı / dokunma yüksekliği (isimden aşağı):"
            card.addView(tl)
            card.addView(chips(listOf("1,5 sn", "2,5 sn", "4 sn"), if (tgtMs <= 1500) 0 else if (tgtMs <= 2500) 1 else 2) { n ->
                prefs.edit().putInt(pk + "tgtms", intArrayOf(1500, 2500, 4000)[n]).commit()
                tgtMs = intArrayOf(1500, 2500, 4000)[n]
                refreshMenu()
            })
            card.addView(chips(listOf("Yakın", "Orta", "Uzak"), tgtOff) { n ->
                prefs.edit().putInt(pk + "tgtoff", n).commit()
                tgtOff = n
                refreshMenu()
            })
            val rl2 = TextView(this)
            rl2.textSize = 11f
            rl2.setTextColor(cText)
            rl2.text = "Av alanı (karakter etrafında):"
            card.addView(rl2)
            card.addView(chips(listOf("Tüm ekran", "Dar", "Orta", "Geniş"), tgtRad) { n ->
                prefs.edit().putInt(pk + "tgtrad", n).commit()
                tgtRad = n
                refreshMenu()
            })
            val tip2 = TextView(this)
            tip2.textSize = 10f
            tip2.setTextColor(cMuted)
            tip2.text = "Canavar yakındayken Hedef dene'ye bas. Karakter yürümüyorsa dokunma yüksekliğini değiştir."
            card.addView(tip2)
        }
        if (nMode == 1) {
            card.addView(btnRow(listOf(
                Pair("Dene + öğren", {
                    autoLearnBtn(pk + "np", pk + "na", nX, nY, true, "Nişan")
                }),
                Pair("Sıfırla", {
                    prefs.edit().remove(pk + "np").remove(pk + "na").commit()
                    refreshMenu()
                })
            )))
            card.addView(btnRow(listOf(
                Pair("Pasifi öğren", {
                    learnOne(pk + "np", nX, nY, "Nişan pasif görünümü")
                }),
                Pair("Aktifi öğren", {
                    learnOne(pk + "na", nX, nY, "Nişan aktif görünümü")
                })
            )))
            val tip = TextView(this)
            tip.textSize = 10f
            tip.setTextColor(cMuted)
            tip.text = "Dene + öğren: Nişan kapalıyken bas. Basar, aktif hâlini öğrenir, tekrar basıp kapatır."
            card.addView(tip)
        }
        col.addView(card, cardLp())
    }

    private fun addPickCard(col: LinearLayout) {
        val pk = "p" + profile + "_"
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(pickOn)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        card.addView(iconSwitch(iconOf(Cfg.IC_EL), "El toplama", pickOn) { on ->
            pickOn = on
            prefs.edit().putBoolean(pk + "pick", on).commit()
            card.background = cardBg(on)
            rebuildPanelIcons()
        })
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = slotText(hX)
        card.addView(info)
        card.addView(btnRow(listOf(
            Pair("Yuva ayarla", {
                pickPoint("El (topla) düğmesine dokun") { fx, fy ->
                    prefs.edit().putFloat(pk + "hx", fx).putFloat(pk + "hy", fy).commit()
                    hX = fx
                    hY = fy
                    toast("Yuva kaydedildi")
                    rebuildPanelIcons()
                }
            }),
            Pair("Dene", {
                if (hX < 0f) {
                    toast("Önce yuvayı ayarla")
                } else {
                    tapFrac(hX, hY)
                    toast("El düğmesine basıldı")
                }
            })
        )))
        card.addView(chips(listOf("Sürekli bas", "Aktif / pasif izle"), hMode) { n ->
            prefs.edit().putInt(pk + "hmode", n).commit()
            hMode = n
            refreshMenu()
        })
        if (hMode == 1) {
            val hi = TextView(this)
            hi.textSize = 10f
            hi.setTextColor(cMuted)
            hi.text = if (hTplP != null && hTplA != null) "El düğmesi görünümü öğrenildi: yalnızca pasifken basar"
            else "Önce Dene + öğren: El kapalıyken bas, düğme basıp aktif hâlini öğrenir"
            card.addView(hi)
            card.addView(btnRow(listOf(
                Pair("Dene + öğren", {
                    autoLearnBtn(pk + "hp", pk + "ha", hX, hY, true, "El")
                }),
                Pair("Sıfırla", {
                    prefs.edit().remove(pk + "hp").remove(pk + "ha").commit()
                    refreshMenu()
                })
            )))
        }
        val pl = TextView(this)
        pl.textSize = 12f
        pl.setTextColor(cText)
        pl.setPadding(0, dpx(6), 0, 0)
        pl.text = "Toplama aralığı: " + pickMs + " ms"
        card.addView(pl)
        val pbar = SeekBar(this)
        pbar.max = 13
        pbar.progress = ((pickMs - 200) / 100).coerceIn(0, 13)
        pbar.progressTintList = ColorStateList.valueOf(cAccent)
        pbar.thumbTintList = ColorStateList.valueOf(cCyan)
        pbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                pickMs = 200 + p * 100
                pl.text = "Toplama aralığı: " + pickMs + " ms"
                prefs.edit().putInt(pk + "pickms", pickMs).commit()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        card.addView(pbar)
        col.addView(card, cardLp())
    }

    private fun addAtkCard(col: LinearLayout) {
        val pk = "p" + profile + "_"
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(aOn)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        card.addView(iconSwitch(sym("sword", cCyan), "Oto saldırı", aOn) { on ->
            aOn = on
            prefs.edit().putBoolean(pk + "atk", on).commit()
            card.background = cardBg(on)
        })
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = slotText(aX)
        card.addView(info)
        card.addView(btnRow(listOf(
            Pair("Yuva ayarla", {
                pickPoint("Saldırı düğmesine dokun") { fx, fy ->
                    prefs.edit().putFloat(pk + "ax", fx).putFloat(pk + "ay", fy).commit()
                    aX = fx
                    aY = fy
                    toast("Yuva kaydedildi")
                    refreshMenu()
                }
            }),
            Pair("Dene", {
                if (aX < 0f) {
                    toast("Önce yuvayı ayarla")
                } else {
                    tapFrac(aX, aY)
                    toast("Saldırı düğmesine basıldı")
                }
            })
        )))
        val pl = TextView(this)
        pl.textSize = 12f
        pl.setTextColor(cText)
        pl.text = "Saldırı aralığı: " + atkMs + " ms"
        card.addView(pl)
        val pbar = SeekBar(this)
        pbar.max = 10
        pbar.progress = ((atkMs - 200) / 100).coerceIn(0, 10)
        pbar.progressTintList = ColorStateList.valueOf(cAccent)
        pbar.thumbTintList = ColorStateList.valueOf(cCyan)
        pbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                atkMs = 200 + p * 100
                pl.text = "Saldırı aralığı: " + atkMs + " ms"
                prefs.edit().putInt(pk + "atkms", atkMs).commit()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        card.addView(pbar)
        col.addView(card, cardLp())
    }

    private fun addPotCard(col: LinearLayout) {
        val pk = "p" + profile + "_"
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(potOn)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        card.addView(iconSwitch(sym("pot", cCyan), "Oto iksir", potOn) { on ->
            potOn = on
            prefs.edit().putBoolean(pk + "pot", on).commit()
            card.background = cardBg(on)
        })
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = slotText(pX)
        card.addView(info)
        card.addView(btnRow(listOf(
            Pair("Yuva ayarla", {
                pickPoint("İksir düğmesine dokun") { fx, fy ->
                    prefs.edit().putFloat(pk + "px", fx).putFloat(pk + "py", fy).commit()
                    pX = fx
                    pY = fy
                    toast("Yuva kaydedildi")
                    refreshMenu()
                }
            }),
            Pair("Dene", {
                if (pX < 0f) {
                    toast("Önce yuvayı ayarla")
                } else {
                    tapFrac(pX, pY)
                    toast("İksir düğmesine basıldı")
                }
            })
        )))
        val pl = TextView(this)
        pl.textSize = 12f
        pl.setTextColor(cText)
        pl.text = "İksir aralığı: " + potSec + " sn"
        card.addView(pl)
        val pbar = SeekBar(this)
        pbar.max = 29
        pbar.progress = (potSec - 1).coerceIn(0, 29)
        pbar.progressTintList = ColorStateList.valueOf(cAccent)
        pbar.thumbTintList = ColorStateList.valueOf(cCyan)
        pbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                potSec = p + 1
                pl.text = "İksir aralığı: " + potSec + " sn"
                prefs.edit().putInt(pk + "potsec", potSec).commit()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        card.addView(pbar)
        col.addView(card, cardLp())
    }

    private fun secP(sc: Int): Int = if (sc <= 40) (sc / 2 - 1).coerceAtLeast(0) else (19 + (sc - 40) / 10).coerceAtMost(39)

    private fun pSec(p: Int): Int = if (p <= 19) (p + 1) * 2 else 40 + (p - 19) * 10

    private fun addSkillCard(col: LinearLayout, i: Int) {
        val pf = profile
        val nm = Cfg.SNAME[pf][i]
        val kk = "s" + pf + "_" + i + "_"
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(skillOn[i])
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))

        val ex = (i == selSk)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setOnClickListener {
            selSk = if (selSk == i) -1 else i
            lastScroll = menuSv?.scrollY ?: 0
            refreshMenu()
        }
        val img = ImageView(this)
        img.setImageDrawable(skillIcon(i))
        img.alpha = if (skillOn[i]) 1f else 0.45f
        head.addView(img, LinearLayout.LayoutParams(dpx(40), dpx(40)))
        val sw = styledSwitch(nm, skillOn[i]) { on ->
            skillOn[i] = on
            prefs.edit().putBoolean(kk + "on", on).commit()
            img.alpha = if (on) 1f else 0.45f
            card.background = cardBg(on)
            rebuildPanelIcons()
        }
        val sp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        sp.leftMargin = dpx(8)
        head.addView(sw, sp)
        card.addView(head)

        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = skillInfo(i) + (if (ex) "" else "  ·  ayar için dokun")
        card.addView(info)
        if (!ex) {
            col.addView(card, cardLp())
            return
        }

        card.addView(btnRow(listOf(
            Pair("Yuvayı bul + dene", { autoFind(i) }),
            Pair("Elle göster", {
                pickPoint(nm + " beceri düğmesine dokun") { fx, fy ->
                    prefs.edit().putFloat(kk + "x", fx).putFloat(kk + "y", fy).commit()
                    bx[i] = fx
                    by[i] = fy
                    toast("Yuva kaydedildi")
                    refreshMenu()
                }
            })
        )))
        card.addView(chips(listOf("Üstte görünür", "Süreyle"), if (smode[i] == 1) 0 else 1) { n ->
            prefs.edit().putInt(kk + "mode", if (n == 0) 1 else 0).commit()
            refreshMenu()
        })
        val test = Pair("Dene", {
            if (bx[i] < 0f) {
                toast("Önce yuvayı bul")
            } else {
                tapFrac(bx[i], by[i])
                toast(nm + " basıldı")
            }
        })
        if (smode[i] == 1) {
            card.addView(btnRow(listOf(
                Pair("İkonu öğren", {
                    if (bx[i] < 0f) toast("Önce yuvayı bul") else autoLearn(i)
                }),
                test,
                Pair("Sıfırla", {
                    prefs.edit().remove(kk + "g").remove(kk + "t").commit()
                    useTimer[i] = false
                    noSee[i] = 0
                    loadCfg()
                    refreshMenu()
                })
            )))
            val tip = TextView(this)
            tip.textSize = 10f
            tip.setTextColor(cMuted)
            tip.text = "İkonu öğren: buff kapalıyken bas. Basar, sol üstte çıkan ikonu bulur ve kaydeder."
            card.addView(tip)
        } else {
            card.addView(btnRow(listOf(test)))
        }
        val sl = TextView(this)
        sl.textSize = 11f
        sl.setTextColor(cText)
        sl.setPadding(0, dpx(6), 0, 0)
        val lead = if (smode[i] == 0) "Yenileme süresi" else "İkon görünmezse yenileme"
        sl.text = lead + ": her " + secs[i] + " sn"
        card.addView(sl)
        val sk = SeekBar(this)
        sk.max = 39
        sk.progress = secP(secs[i])
        sk.progressTintList = ColorStateList.valueOf(cAccent)
        sk.thumbTintList = ColorStateList.valueOf(cCyan)
        sk.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                secs[i] = pSec(p)
                sl.text = lead + ": her " + secs[i] + " sn"
                prefs.edit().putInt(kk + "sec", secs[i]).commit()
                info.text = skillInfo(i)
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        card.addView(sk)
        col.addView(card, cardLp())
    }

    // İkon seçme ekranı: karakterin tüm becerileri kare ikonlar olarak
    private fun addSkillGrid(col: LinearLayout) {
        if (selSk >= nSk) selSk = 0
        val per = 5
        var rowL: LinearLayout? = null
        for (i in 0 until nSk) {
            if (i % per == 0) {
                val nr = LinearLayout(this)
                nr.orientation = LinearLayout.HORIZONTAL
                col.addView(nr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                rowL = nr
            }
            val r = rowL ?: continue
            val on = skillOn[i]
            val tile = FrameLayout(this)
            tile.background = if (i == selSk) shape(0xFF0F2A4F.toInt(), cCyan, 9, 2)
            else shape(0xFF081426.toInt(), if (on) cAccent else 0xFF1C3A63.toInt(), 9, 1)
            val iv = ImageView(this)
            iv.setImageDrawable(skillIcon(i))
            iv.alpha = if (on) 1f else 0.5f
            iv.setPadding(dpx(5), dpx(5), dpx(5), dpx(5))
            tile.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val dot = View(this)
            val dg = GradientDrawable()
            dg.shape = GradientDrawable.OVAL
            dg.setColor(if (bx[i] >= 0f) 0xFF6DD66D.toInt() else 0xFF4A3A22.toInt())
            dot.background = dg
            val dp0 = FrameLayout.LayoutParams(dpx(8), dpx(8), Gravity.TOP or Gravity.END)
            dp0.topMargin = dpx(4)
            dp0.rightMargin = dpx(4)
            tile.addView(dot, dp0)
            tile.setOnClickListener {
                selSk = i
                lastScroll = menuSv?.scrollY ?: 0
                refreshMenu()
            }
            val p = LinearLayout.LayoutParams(0, dpx(50), 1f)
            p.leftMargin = dpx(2)
            p.rightMargin = dpx(2)
            p.topMargin = dpx(3)
            r.addView(tile, p)
        }
        val rem = nSk % per
        val rr = rowL
        if (rem != 0 && rr != null) {
            for (k in rem until per) {
                val sp = View(this)
                val p = LinearLayout.LayoutParams(0, dpx(50), 1f)
                rr.addView(sp, p)
            }
        }
    }

    // ---------------- Metin taşı avı ----------------

    private class MtRes(val x: Float, val y: Float, val cells: Int, val dist: Float)

    private val mtN = Cfg.MT_NAME.size
    private var mtOn = false
    private val mtSel = BooleanArray(Cfg.MT_NAME.size)
    private val mtSig = arrayOfNulls<IntArray>(Cfg.MT_NAME.size)
    private val mtTaught = BooleanArray(Cfg.MT_NAME.size)
    private var mtJx = 0.14f
    private var mtJy = 0.72f
    private var mtJrI = 1
    private var mtLootI = 1
    private var mtOpen = false
    private var mtState = 0
    private var mtSince = 0L
    private var mtLost = 0
    private var mtSeen = 0L
    private var mtHead = 0f
    private var mtLegEnd = 0L
    private var mtPrev: IntArray? = null
    private var mtStuckAt = 0L
    private var mtLootTap = 0L
    private var mtBroken = 0
    private var joyGen = 0
    private var joyOn = false
    private var joyAng = 0f
    private var atkHold = false
    private var atkGen = 0
    private var mtWarned = 0L
    private var mtHpT: IntArray? = null
    private var mtHpX = -1f
    private var mtHpY = -1f
    private var mtMaxI = 1
    private var mtIgnoreUntil = 0L
    private var menuRun: TextView? = null
    private var statKill: TextView? = null
    private var statTime: TextView? = null
    private var statState: TextView? = null
    private fun mtMaxSec(): Int = intArrayOf(60, 120, 180)[mtMaxI.coerceIn(0, 2)]

    private fun mtJr(): Float = floatArrayOf(0.05f, 0.07f, 0.09f)[mtJrI.coerceIn(0, 2)]
    private fun mtLootSec(): Int = intArrayOf(3, 5, 8)[mtLootI.coerceIn(0, 2)]

    private fun sigOf(px: IntArray): IntArray {
        val cnt = IntArray(512)
        val sr = IntArray(512)
        val sg = IntArray(512)
        val sb = IntArray(512)
        var tot = 0
        for (c in px) {
            if (((c shr 24) and 255) < 128) continue
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            if (r + g + b < 90) continue
            val k = (r shr 5) * 64 + (g shr 5) * 8 + (b shr 5)
            cnt[k]++
            sr[k] += r
            sg[k] += g
            sb[k] += b
            tot++
        }
        val out = ArrayList<Int>()
        if (tot == 0) return IntArray(0)
        for (n in 0 until 6) {
            var bi = -1
            var bc = 0
            for (k in 0 until 512) {
                if (cnt[k] > bc) {
                    bc = cnt[k]
                    bi = k
                }
            }
            if (bi < 0 || bc * 100 < tot * 5) break
            out.add(sr[bi] / bc)
            out.add(sg[bi] / bc)
            out.add(sb[bi] / bc)
            cnt[bi] = 0
        }
        return out.toIntArray()
    }

    private fun loadMt() {
        mtOn = prefs.getBoolean("mt_on", false)
        mtJx = prefs.getFloat("mt_jx", 0.14f)
        mtJy = prefs.getFloat("mt_jy", 0.72f)
        mtJrI = prefs.getInt("mt_jr", 1)
        mtLootI = prefs.getInt("mt_loot", 1)
        mtMaxI = prefs.getInt("mt_max", 1)
        mtHpX = prefs.getFloat("mt_hpx", -1f)
        mtHpY = prefs.getFloat("mt_hpy", -1f)
        val hs = prefs.getString("mt_hpt", null)
        mtHpT = if (hs != null) decodeTpl(hs) else null
        for (i in 0 until mtN) {
            mtSel[i] = prefs.getBoolean("mt_s" + i, false)
            val st = prefs.getString("mt_c" + i, null)
            if (st != null && st.isNotEmpty()) {
                try {
                    mtSig[i] = st.split(",").map { it.toInt() }.toIntArray()
                    mtTaught[i] = true
                } catch (e: Exception) {
                    mtSig[i] = null
                }
            } else {
                mtTaught[i] = false
            }
            if (!mtTaught[i] && mtSig[i] == null) {
                try {
                    val bytes = Base64.decode(Cfg.MT_ICON[i], Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    val px = IntArray(bmp.width * bmp.height)
                    bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                    mtSig[i] = sigOf(px)
                } catch (e: Exception) {
                    mtSig[i] = null
                }
            }
        }
    }

    private fun mtSigList(): List<IntArray> {
        val l = ArrayList<IntArray>()
        for (i in 0 until mtN) {
            val s = mtSig[i]
            if (mtSel[i] && s != null && s.size >= 3) l.add(s)
        }
        return l
    }

    // Ekranda seçili metin taşı renklerini arar. Döner: en yakın taş + kare imzası (takılma kontrolü)
    private fun mtAnalyze(b: Bitmap, sigs: List<IntArray>): Pair<MtRes?, IntArray> {
        val sw = 320
        val sh = (sw.toFloat() * b.height / b.width).toInt().coerceAtLeast(18)
        val sm = Bitmap.createScaledBitmap(b, sw, sh, true)
        val px = IntArray(sw * sh)
        sm.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (sm !== b) sm.recycle()
        val fs = IntArray(144)
        for (gy in 0 until 9) {
            for (gx in 0 until 16) {
                val c = px[(gy * sh / 9 + sh / 18) * sw + gx * sw / 16 + sw / 32]
                fs[gy * 16 + gx] = (((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255)) / 3
            }
        }
        val cs = 8
        val gw = sw / cs
        val gh = sh / cs
        val cnt = IntArray(gw * gh)
        for (y in 0 until gh * cs) {
            val fy = y.toFloat() / sh
            if (fy < 0.12f || fy > 0.88f) continue
            for (x in 0 until gw * cs) {
                val fx = x.toFloat() / sw
                if (fx < 0.24f && fy > 0.5f) continue
                if (fx > 0.70f && fy > 0.45f) continue
                val c = px[y * sw + x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val bl = c and 255
                var hit = false
                for (s in sigs) {
                    var k = 0
                    while (k + 2 < s.size) {
                        if (abs(r - s[k]) + abs(g - s[k + 1]) + abs(bl - s[k + 2]) < 60) {
                            hit = true
                            break
                        }
                        k += 3
                    }
                    if (hit) break
                }
                if (hit) cnt[(y / cs) * gw + x / cs]++
            }
        }
        val seen = BooleanArray(gw * gh)
        var best: MtRes? = null
        val aspect = sw.toFloat() / sh
        for (st in 0 until gw * gh) {
            if (seen[st] || cnt[st] < 22) continue
            val stack = ArrayList<Int>()
            stack.add(st)
            seen[st] = true
            var n = 0
            var sx = 0f
            var sy = 0f
            while (stack.isNotEmpty()) {
                val k = stack.removeAt(stack.size - 1)
                val kx = k % gw
                val ky = k / gw
                n++
                sx += kx + 0.5f
                sy += ky + 0.5f
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val nx = kx + dx
                        val ny = ky + dy
                        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                        val nk = ny * gw + nx
                        if (!seen[nk] && cnt[nk] >= 22) {
                            seen[nk] = true
                            stack.add(nk)
                        }
                    }
                }
            }
            if (n < 3 || n > gw * gh * 35 / 100) continue
            val fx = sx / n * cs / sw
            val fy = sy / n * cs / sh
            val ddx = (fx - 0.5f) * aspect
            val ddy = fy - 0.55f
            val d = Math.sqrt((ddx * ddx + ddy * ddy).toDouble()).toFloat()
            val bb = best
            if (bb == null || d < bb.dist) best = MtRes(fx, fy, n, d)
        }
        return Pair(best, fs)
    }

    private fun mtProcess(bmp: Bitmap) {
        val sigs = mtSigList()
        if (sigs.isEmpty()) return
        val res = mtAnalyze(bmp, sigs)
        val ht = mtHpT
        val hp = if (ht != null && mtHpX >= 0f) (if (analyzeRevive(bmp, ht, mtHpX, mtHpY) < 24f) 1 else 0) else -1
        handler.post { mtAct(res.first, res.second, hp) }
    }

    private fun angDiff(a: Float, b: Float): Float {
        var d = a - b
        val pi = Math.PI.toFloat()
        while (d > pi) d -= 2f * pi
        while (d < -pi) d += 2f * pi
        return Math.abs(d)
    }

    private fun joyPoint(ang: Float): FloatArray {
        val s = screen()
        val r = mtJr() * s[1]
        return floatArrayOf(
            mtJx * s[0] + Math.cos(ang.toDouble()).toFloat() * r,
            mtJy * s[1] + Math.sin(ang.toDouble()).toFloat() * r
        )
    }

    // Joystick'i verilen yöne çevirip basılı tutar (zincirleme sürekli hareket)
    private fun joyStart(ang: Float) {
        val gen = ++joyGen
        joyOn = true
        joyAng = ang
        val s = screen()
        val p = joyPoint(ang)
        val path = Path()
        path.moveTo(mtJx * s[0], mtJy * s[1])
        path.lineTo(p[0], p[1])
        val st = GestureDescription.StrokeDescription(path, 0, 120, true)
        joyChain(st, gen, 0)
    }

    private fun joyChain(st: GestureDescription.StrokeDescription, gen: Int, n: Int) {
        try {
            val g = GestureDescription.Builder().addStroke(st).build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    handler.post { joyNext(st, gen, n) }
                }

                override fun onCancelled(d: GestureDescription?) {
                    handler.post { if (gen == joyGen) joyOn = false }
                }
            }, null)
            if (!ok && gen == joyGen) joyOn = false
        } catch (e: Exception) {
            if (gen == joyGen) joyOn = false
        }
    }

    private fun joyNext(prev: GestureDescription.StrokeDescription, gen: Int, n: Int) {
        if (gen != joyGen || !joyOn) return
        try {
            val p = joyPoint(joyAng)
            val path = Path()
            path.moveTo(p[0], p[1])
            if (n >= 50) {
                val last = prev.continueStroke(path, 0, 40, false)
                joyOn = false
                dispatchGesture(GestureDescription.Builder().addStroke(last).build(), null, null)
                return
            }
            val nx = prev.continueStroke(path, 0, 600, true)
            joyChain(nx, gen, n + 1)
        } catch (e: Exception) {
            joyOn = false
        }
    }

    // Joystick'i bırak: orta noktaya kısa dokunuş eski basışı iptal eder
    private fun joyRelease() {
        joyGen++
        val was = joyOn
        joyOn = false
        if (!was) return
        try {
            val s = screen()
            val path = Path()
            path.moveTo(mtJx * s[0], mtJy * s[1])
            dispatchGesture(
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 30)).build(),
                null, null
            )
        } catch (e: Exception) {
        }
    }

    // Saldırı düğmesini basılı tut (zincirleme)
    private fun atkStart() {
        if (aX < 0f) return
        val gen = ++atkGen
        atkHold = true
        val s = screen()
        val path = Path()
        path.moveTo(aX * s[0], aY * s[1])
        atkChain(GestureDescription.StrokeDescription(path, 0, 1200, true), gen, 0)
    }

    private fun atkChain(st: GestureDescription.StrokeDescription, gen: Int, n: Int) {
        try {
            val ok = dispatchGesture(GestureDescription.Builder().addStroke(st).build(), object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    handler.post { atkNext(st, gen, n) }
                }

                override fun onCancelled(d: GestureDescription?) {
                    handler.post { if (gen == atkGen) atkHold = false }
                }
            }, null)
            if (!ok && gen == atkGen) atkHold = false
        } catch (e: Exception) {
            if (gen == atkGen) atkHold = false
        }
    }

    private fun atkNext(prev: GestureDescription.StrokeDescription, gen: Int, n: Int) {
        if (gen != atkGen || !atkHold) return
        try {
            val s = screen()
            val path = Path()
            path.moveTo(aX * s[0], aY * s[1])
            if (n >= 40) {
                atkHold = false
                dispatchGesture(GestureDescription.Builder().addStroke(prev.continueStroke(path, 0, 40, false)).build(), null, null)
                return
            }
            atkChain(prev.continueStroke(path, 0, 1200, true), gen, n + 1)
        } catch (e: Exception) {
            atkHold = false
        }
    }

    private fun atkRelease() {
        atkGen++
        val was = atkHold
        atkHold = false
        if (!was || aX < 0f) return
        try {
            val s = screen()
            val path = Path()
            path.moveTo(aX * s[0], aY * s[1])
            dispatchGesture(
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 30)).build(),
                null, null
            )
        } catch (e: Exception) {
        }
    }

    private fun updateStats() {
        val s = (SystemClock.elapsedRealtime() - startAt) / 1000
        statTime?.text = if (running) "%02d:%02d".format(s / 60, s % 60) else "00:00"
        statKill?.text = mtBroken.toString()
        statState?.text = if (!running) "Bekliyor" else if (!mtOn) "Av" else when (mtState) {
            0 -> "Arıyor"
            1 -> "Gidiyor"
            2 -> "Saldırıyor"
            else -> "Loot"
        }
    }

    private fun mtReset() {
        mtState = 0
        mtSince = SystemClock.elapsedRealtime()
        mtLost = 0
        mtSeen = 0L
        mtPrev = null
        mtStuckAt = 0L
        mtLegEnd = 0L
        mtHead = (Math.random() * 6.28).toFloat()
        mtBroken = 0
        joyGen++
        joyOn = false
        atkGen++
        atkHold = false
    }

    private fun mtStop() {
        joyRelease()
        atkRelease()
    }

    private fun mtAct(res: MtRes?, fs: IntArray, hp: Int) {
        val now = SystemClock.elapsedRealtime()
        if (!running || !mtOn || !inGame) return
        if (now < restUntil) {
            mtStop()
            return
        }
        if (aX < 0f && now - mtWarned > 20000L) {
            mtWarned = now
            toast("Metin avı için Oto saldırı yuvasını ayarla")
        }
        when (mtState) {
            0 -> {
                if (res != null && res.cells >= 3 && now >= mtIgnoreUntil) {
                    mtState = 1
                    mtSince = now
                    mtSeen = now
                    mtLost = 0
                    toast("Metin bulundu")
                    return
                }
                patrol(now, fs)
            }
            1 -> {
                if (now - mtSince > 20000L) {
                    joyRelease()
                    mtState = 0
                    mtLegEnd = 0L
                    mtHead += 3.1f
                    mtIgnoreUntil = now + 6000L
                    return
                }
                if (res == null) {
                    if (now - mtSeen > 2500L) {
                        mtState = 0
                        mtLegEnd = 0L
                    }
                    return
                }
                mtSeen = now
                if (res.dist < 0.17f) {
                    joyRelease()
                    tapFrac(res.x, res.y)
                    mtState = 2
                    mtSince = now
                    mtLost = 0
                    return
                }
                val dx = (res.x - 0.5f) * (screen()[0].toFloat() / screen()[1])
                val dy = res.y - 0.55f
                val ang = Math.atan2(dy.toDouble(), dx.toDouble()).toFloat()
                if (!joyOn || angDiff(ang, joyAng) > 0.35f) joyStart(ang)
            }
            2 -> {
                if (!atkHold) atkStart()
                if (hp >= 0) {
                    if (hp == 1) mtLost = 0 else mtLost++
                } else if (res != null && res.dist < 0.30f) {
                    mtLost = 0
                } else if (res != null) {
                    atkRelease()
                    mtState = 1
                    mtSince = now
                    mtSeen = now
                    return
                } else {
                    mtLost++
                }
                if (mtLost >= (if (hp >= 0) 3 else 5) && now - mtSince > 2500L) {
                    atkRelease()
                    mtState = 3
                    mtSince = now
                    mtBroken++
                    return
                }
                if (now - mtSince > mtMaxSec() * 1000L) {
                    atkRelease()
                    mtState = 0
                    mtLegEnd = 0L
                    mtHead += 3.1f
                    mtIgnoreUntil = now + 6000L
                }
            }
            3 -> {
                if (hX >= 0f && now - mtLootTap > 300L) {
                    mtLootTap = now
                    tapFrac(hX, hY)
                }
                if (now - mtSince > mtLootSec() * 1000L) {
                    mtState = 0
                    mtLegEnd = 0L
                    mtHead += 2.4f
                }
            }
        }
    }

    // Gezinti: yön değiştirerek dolaş, takılırsa dön
    private fun patrol(now: Long, fs: IntArray) {
        val prev = mtPrev
        mtPrev = fs
        if (joyOn && prev != null && prev.size == fs.size) {
            var d = 0
            for (k in fs.indices) d += abs(fs[k] - prev[k])
            d /= fs.size
            if (d < 3) {
                if (mtStuckAt == 0L) {
                    mtStuckAt = now
                } else if (now - mtStuckAt > 1400L) {
                    mtStuckAt = 0L
                    mtHead += 2.2f + (Math.random() * 1.4).toFloat()
                    mtLegEnd = now + 2500L
                    joyStart(mtHead)
                    return
                }
            } else {
                mtStuckAt = 0L
            }
        }
        if (!joyOn || now >= mtLegEnd) {
            if (mtLegEnd != 0L) mtHead += ((Math.random() - 0.5) * 2.2).toFloat()
            mtLegEnd = now + 2500L + (Math.random() * 2500).toLong()
            joyStart(mtHead)
        }
    }

    // Menüdeki "Öğret": oyunda taşa dokun, rengi kaydedilir
    private fun mtTeach(i: Int) {
        pickPoint(Cfg.MT_NAME[i] + " taşına dokun") { fx, fy ->
            autoBusy = true
            handler.postDelayed({
                grab { b ->
                    handler.post {
                        autoBusy = false
                        if (b == null) {
                            toast("Ekran alınamadı")
                        } else {
                            val half = (0.045f * b.height).toInt().coerceAtLeast(6)
                            val cx = (fx * b.width).toInt()
                            val cy = (fy * b.height).toInt()
                            val x0 = (cx - half).coerceIn(0, b.width - 2)
                            val y0 = (cy - half).coerceIn(0, b.height - 2)
                            val w = (half * 2).coerceAtMost(b.width - x0)
                            val h = (half * 2).coerceAtMost(b.height - y0)
                            val px = IntArray(w * h)
                            b.getPixels(px, 0, w, x0, y0, w, h)
                            val sg = sigOf(px)
                            if (sg.size < 3) {
                                toast("Renk alınamadı, tekrar dene")
                            } else {
                                prefs.edit().putString("mt_c" + i, sg.joinToString(",")).commit()
                                mtSig[i] = sg
                                mtTaught[i] = true
                                toast(Cfg.MT_NAME[i] + " öğrenildi")
                                refreshMenu()
                            }
                        }
                    }
                }
            }, 350L)
        }
    }

    private fun mtLearnHp() {
        pickPoint("Taşa saldırırken hedef HP çubuğuna dokun") { fx, fy ->
            autoBusy = true
            handler.postDelayed({
                grab { b ->
                    handler.post {
                        autoBusy = false
                        val tp = if (b != null) cropRv(b, fx, fy) else null
                        if (tp == null) {
                            toast("Öğrenilemedi, tekrar dene")
                        } else {
                            prefs.edit().putString("mt_hpt", tp).putFloat("mt_hpx", fx).putFloat("mt_hpy", fy).commit()
                            mtHpT = decodeTpl(tp)
                            mtHpX = fx
                            mtHpY = fy
                            toast("HP çubuğu öğrenildi")
                            refreshMenu()
                        }
                    }
                }
            }, 350L)
        }
    }

    private fun addMetinHpCard(col: LinearLayout) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(mtHpT != null)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        val h = TextView(this)
        h.text = "Hedef HP çubuğu"
        h.textSize = 13f
        h.setTypeface(h.typeface, Typeface.BOLD)
        h.setTextColor(cText)
        card.addView(h)
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = if (mtHpT != null) "Ayarlı: çubuk kaybolunca metin kırıldı sayılır" else "Ayarlanmadı: kırılma renkten tahmin edilir"
        card.addView(info)
        card.addView(btnRow(listOf(
            Pair("Çubuğu seç", { mtLearnHp() }),
            Pair("Sıfırla", {
                prefs.edit().remove("mt_hpt").remove("mt_hpx").remove("mt_hpy").commit()
                mtHpT = null
                mtHpX = -1f
                refreshMenu()
            })
        )))
        val l = TextView(this)
        l.textSize = 11f
        l.setTextColor(cText)
        l.text = "Savaş azami süre (takılırsa vazgeç)"
        card.addView(l)
        card.addView(chips(listOf("1 dk", "2 dk", "3 dk"), mtMaxI) { n ->
            mtMaxI = n
            prefs.edit().putInt("mt_max", n).commit()
            refreshMenu()
        })
        col.addView(card, cardLp())
    }

    private fun mtTest() {
        val sigs = mtSigList()
        if (sigs.isEmpty()) {
            toast("Önce en az bir taş seç")
            return
        }
        if (Build.VERSION.SDK_INT < 30) return
        autoBusy = true
        grab { b ->
            val r = if (b != null) mtAnalyze(b, sigs).first else null
            handler.post {
                autoBusy = false
                if (b == null) {
                    toast("Ekran alınamadı")
                } else if (r == null) {
                    toast("Metin görünmüyor")
                } else {
                    val xs = if (r.x < 0.33f) "sol" else if (r.x > 0.66f) "sağ" else "orta"
                    val ys = if (r.y < 0.4f) "üst" else if (r.y > 0.65f) "alt" else "orta"
                    toast("Metin bulundu: " + ys + " " + xs)
                }
            }
        }
    }

    private fun addMetinCard(col: LinearLayout) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(mtOn)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        card.addView(iconSwitch(iconOf(Cfg.MT_ICON[5]), "Metin taşı avı", mtOn) { on ->
            mtOn = on
            prefs.edit().putBoolean("mt_on", on).commit()
            card.background = cardBg(on)
            mtReset()
            if (!on) mtStop()
        })
        var ns = 0
        for (i in 0 until mtN) if (mtSel[i]) ns++
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = "Seçili taş: " + ns + "  |  Saldırı: " + (if (aX >= 0f) "ayarlı" else "yok") + "  |  El: " + (if (hX >= 0f) "ayarlı" else "yok")
        card.addView(info)
        card.addView(stoneBtn(if (mtOpen) "Listeyi kapat" else "Taşları seç", 12f) {
            mtOpen = !mtOpen
            refreshMenu()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpx(34)).also { it.topMargin = dpx(4) })
        if (mtOpen) {
            for (i in 0 until mtN) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                val img = ImageView(this)
                img.setImageDrawable(iconOf(Cfg.MT_ICON[i]))
                img.alpha = if (mtSel[i]) 1f else 0.4f
                row.addView(img, LinearLayout.LayoutParams(dpx(32), dpx(32)))
                val sw = styledSwitch(Cfg.MT_NAME[i] + " " + Cfg.MT_LV[i] + (if (mtTaught[i]) " *" else ""), mtSel[i]) { on ->
                    mtSel[i] = on
                    img.alpha = if (on) 1f else 0.4f
                    prefs.edit().putBoolean("mt_s" + i, on).commit()
                }
                sw.textSize = 11f
                val sp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                sp.leftMargin = dpx(6)
                row.addView(sw, sp)
                val tb = stoneBtn("Öğret", 10f) { mtTeach(i) }
                val tp = LinearLayout.LayoutParams(dpx(46), dpx(28))
                tp.leftMargin = dpx(4)
                row.addView(tb, tp)
                card.addView(row)
            }
            val hint = TextView(this)
            hint.textSize = 10f
            hint.setTextColor(cMuted)
            hint.text = "Öğret: taşın yanına git, Öğret'e bas, oyunda taşa dokun. * öğrenilmiş demek."
            card.addView(hint)
        }
        val jinfo = TextView(this)
        jinfo.textSize = 11f
        jinfo.setTextColor(cMuted)
        jinfo.text = if (prefs.contains("mt_jx")) "Joystick: ayarlı" else "Joystick: varsayılan (ayarla)"
        card.addView(jinfo)
        card.addView(btnRow(listOf(
            Pair("Joystick ayarla", {
                pickPoint("Joystick'in tam ortasına dokun") { fx, fy ->
                    prefs.edit().putFloat("mt_jx", fx).putFloat("mt_jy", fy).commit()
                    mtJx = fx
                    mtJy = fy
                    toast("Joystick kaydedildi")
                    refreshMenu()
                }
            }),
            Pair("Taşı tara", { mtTest() })
        )))
        val l1 = TextView(this)
        l1.textSize = 11f
        l1.setTextColor(cText)
        l1.text = "Joystick erişimi"
        card.addView(l1)
        card.addView(chips(listOf("Dar", "Orta", "Geniş"), mtJrI) { n ->
            mtJrI = n
            prefs.edit().putInt("mt_jr", n).commit()
            refreshMenu()
        })
        val l2 = TextView(this)
        l2.textSize = 11f
        l2.setTextColor(cText)
        l2.text = "Loot toplama süresi"
        card.addView(l2)
        card.addView(chips(listOf("3 sn", "5 sn", "8 sn"), mtLootI) { n ->
            mtLootI = n
            prefs.edit().putInt("mt_loot", n).commit()
            refreshMenu()
        })
        col.addView(card, cardLp())
    }

    private fun addReviveCard(col: LinearLayout) {
        val pk = "p" + profile + "_"
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(rvOn)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        card.addView(iconSwitch(sym("heart", cCyan), "Oto diriliş", rvOn) { on ->
            rvOn = on
            prefs.edit().putBoolean(pk + "rv", on).commit()
            card.background = cardBg(on)
        })
        val info = TextView(this)
        info.textSize = 11f
        info.setTextColor(cMuted)
        info.text = if (rvT != null) "Burdan yeniden başla yazısı öğrenildi" else "Yazı öğretilmedi"
        card.addView(info)
        card.addView(btnRow(listOf(
            Pair("Yazıyı öğret", { learnRevive() }),
            Pair("Dene", {
                if (rvFx < 0f) {
                    toast("Önce yazıyı öğret")
                } else {
                    tapFrac(rvFx, rvFy)
                    toast("Basıldı")
                }
            }),
            Pair("Sıfırla", {
                prefs.edit().remove(pk + "rvt").remove(pk + "rvx").remove(pk + "rvy").commit()
                refreshMenu()
            })
        )))
        val pl = TextView(this)
        pl.textSize = 12f
        pl.setTextColor(cText)
        pl.setPadding(0, dpx(6), 0, 0)
        pl.text = "Kalkınca bekleme: " + rvWait + " sn"
        card.addView(pl)
        val pbar = SeekBar(this)
        pbar.max = 29
        pbar.progress = ((rvWait - 2) / 2).coerceIn(0, 29)
        pbar.progressTintList = ColorStateList.valueOf(cAccent)
        pbar.thumbTintList = ColorStateList.valueOf(cCyan)
        pbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                rvWait = 2 + p * 2
                pl.text = "Kalkınca bekleme: " + rvWait + " sn"
                prefs.edit().putInt(pk + "rvwait", rvWait).commit()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        card.addView(pbar)
        val tip = TextView(this)
        tip.textSize = 10f
        tip.setTextColor(cMuted)
        tip.text = "Karakter ölünce çıkan Burdan yeniden başla yazısı ekrandayken Yazıyı öğret'e bas ve yazıya dokun. Yazıya art arda basar, karakter kalkınca bekler, sonra kaldığı yerden devam eder."
        card.addView(tip)
        col.addView(card, cardLp())
    }

    private fun addSpeedCard(col: LinearLayout) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = cardBg(false)
        card.setPadding(dpx(8), dpx(6), dpx(8), dpx(6))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.setImageDrawable(sym("bolt", cCyan))
        head.addView(iv, LinearLayout.LayoutParams(dpx(30), dpx(30)))
        val tt = TextView(this)
        tt.text = "Tarama hızı"
        tt.textSize = 13f
        tt.setTypeface(tt.typeface, Typeface.BOLD)
        tt.setTextColor(cText)
        tt.setPadding(dpx(8), 0, 0, 0)
        head.addView(tt)
        card.addView(head)
        val cur = prefs.getInt("scangap", 30)
        card.addView(chips(listOf("Hızlı", "Dengeli", "Tasarruf"), if (cur <= 30) 0 else if (cur <= 120) 1 else 2) { n ->
            val v = intArrayOf(30, 120, 300)[n]
            prefs.edit().putInt("scangap", v).commit()
            scanGap = v.toLong()
            refreshMenu()
        })
        val tip = TextView(this)
        tip.textSize = 10f
        tip.setTextColor(cMuted)
        tip.text = "Hızlı: en kısa tepki süresi. Telefon ısınır ya da oyun kasarsa Dengeli veya Tasarruf seç."
        card.addView(tip)
        col.addView(card, cardLp())
    }

    private fun mScale(): Float = prefs.getFloat("mscale", 1f).coerceIn(0.6f, 1.5f)

    private fun setMenuScale(v: Float) {
        prefs.edit().putFloat("mscale", v.coerceIn(0.6f, 1.5f)).commit()
        lastScroll = menuSv?.scrollY ?: 0
        refreshMenu()
    }

    private fun tabBtn(kind: String, label: String, on: Boolean, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER
        c.setPadding(0, dpx(7), 0, dpx(7))
        val iv = ImageView(this)
        iv.setImageDrawable(sym(kind, if (on) cCyan else cMuted))
        c.addView(iv, LinearLayout.LayoutParams(dpx(16), dpx(16)))
        val t = TextView(this)
        t.text = label
        t.textSize = 12f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(if (on) cCyan else cMuted)
        t.setPadding(dpx(5), 0, 0, 0)
        c.addView(t)
        c.background = if (on) shape(0xFF0F2A4F.toInt(), cAccent, 8, 1) else null
        c.setOnClickListener { onClick() }
        return c
    }

    private fun buildMenu(): View {
        val sc = screen()
        val g = Cfg.PGAME[profile]
        val w0 = dpx(300)
        val h0 = dpx(480)
        val fit = minOf(sc[0] * 0.96f / w0, sc[1] * 0.94f / h0)
        val sca = minOf(1f, fit)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = glass(20)
        root.setPadding(dpx(10), dpx(8), dpx(10), dpx(8))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(logoRes(g))
        row.addView(logo, LinearLayout.LayoutParams(dpx(34), dpx(34)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dpx(8), 0, 0, 0)
        val title = TextView(this)
        title.text = "OTO AV"
        title.textSize = 15f
        title.letterSpacing = 0.12f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(cCyan)
        tcol.addView(title)
        val sub = TextView(this)
        sub.text = gname(g)
        sub.textSize = 10f
        sub.setTextColor(cMuted)
        tcol.addView(sub)
        row.addView(tcol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val rb = TextView(this)
        rb.text = if (running) "Durdur" else "Başlat"
        rb.textSize = 12f
        rb.gravity = Gravity.CENTER
        rb.setTypeface(rb.typeface, Typeface.BOLD)
        rb.setTextColor(0xFF04101F.toInt())
        val rbg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2A8CFF.toInt(), 0xFF38C6FF.toInt()))
        rbg.cornerRadius = dpx(10).toFloat()
        rb.background = rbg
        rb.setOnClickListener {
            toggle()
            handler.postDelayed({ menuRun?.text = if (running) "Durdur" else "Başlat" }, 200L)
        }
        menuRun = rb
        val rbp = LinearLayout.LayoutParams(dpx(70), dpx(30))
        rbp.rightMargin = dpx(6)
        row.addView(rb, rbp)
        val cb = symBtn("close", dpx(7)) { showMenu(false) }
        row.addView(cb, LinearLayout.LayoutParams(dpx(32), dpx(32)))
        root.addView(row)

        val crow = LinearLayout(this)
        crow.orientation = LinearLayout.HORIZONTAL
        for (k in 0 until Cfg.PNAME.size) {
            if (Cfg.PGAME[k] != g) continue
            val on = (k == profile)
            val t = TextView(this)
            t.text = Cfg.PNAME[k]
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(if (on) 0xFF04101F.toInt() else cText)
            val bgd = GradientDrawable()
            bgd.cornerRadius = dpx(10).toFloat()
            if (on) {
                bgd.colors = intArrayOf(0xFF2A8CFF.toInt(), 0xFF38C6FF.toInt())
                bgd.orientation = GradientDrawable.Orientation.LEFT_RIGHT
            } else {
                bgd.setColor(0x33FFFFFF)
                bgd.setStroke(dpx(1), 0x44FFFFFF)
            }
            t.background = bgd
            t.setOnClickListener {
                selSk = -1
                switchProfile(k)
            }
            val p = LinearLayout.LayoutParams(0, dpx(34), 1f)
            p.leftMargin = dpx(2)
            p.rightMargin = dpx(2)
            crow.addView(t, p)
        }
        val clp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.topMargin = dpx(8)
        root.addView(crow, clp)

        // sekmeler
        val trow = LinearLayout(this)
        trow.orientation = LinearLayout.HORIZONTAL
        val tabs = listOf("AV", "METİN", "BECERİ", "AYAR")
        for (k in tabs.indices) {
            val on = (k == mTab)
            val tv = TextView(this)
            tv.text = tabs[k]
            tv.textSize = 11f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setTextColor(if (on) 0xFF04101F.toInt() else cText)
            val tg = GradientDrawable()
            tg.cornerRadius = dpx(9).toFloat()
            if (on) {
                tg.colors = intArrayOf(0xFF2A8CFF.toInt(), 0xFF38C6FF.toInt())
                tg.orientation = GradientDrawable.Orientation.LEFT_RIGHT
            } else {
                tg.setColor(0x22FFFFFF)
                tg.setStroke(dpx(1), 0x33FFFFFF)
            }
            tv.background = tg
            tv.setOnClickListener {
                mTab = k
                lastScroll = 0
                refreshMenu()
            }
            val tp = LinearLayout.LayoutParams(0, dpx(30), 1f)
            tp.leftMargin = dpx(2)
            tp.rightMargin = dpx(2)
            trow.addView(tv, tp)
        }
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = dpx(6)
        root.addView(trow, tlp)

        // istatistik şeridi
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        fun statBox(label: String): TextView {
            val bx = LinearLayout(this)
            bx.orientation = LinearLayout.VERTICAL
            bx.gravity = Gravity.CENTER
            bx.background = shape(0xFF081426.toInt(), 0xFF1C3A63.toInt(), 8, 1)
            val v = TextView(this)
            v.textSize = 13f
            v.setTypeface(v.typeface, Typeface.BOLD)
            v.setTextColor(cCyan)
            v.gravity = Gravity.CENTER
            bx.addView(v)
            val l = TextView(this)
            l.text = label
            l.textSize = 9f
            l.setTextColor(cMuted)
            l.gravity = Gravity.CENTER
            bx.addView(l)
            val sp = LinearLayout.LayoutParams(0, dpx(38), 1f)
            sp.leftMargin = dpx(2)
            sp.rightMargin = dpx(2)
            srow.addView(bx, sp)
            return v
        }
        statKill = statBox("Kırılan")
        statTime = statBox("Süre")
        statState = statBox("Durum")
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dpx(6)
        root.addView(srow, slp)
        updateStats()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (mTab == 0) {
            col.addView(sectionHead("AV"))
            addNisanCard(col)
            addPickCard(col)
            addAtkCard(col)
            addReviveCard(col)
        } else if (mTab == 1) {
            col.addView(sectionHead("OTO METİN"))
            addMetinCard(col)
            addMetinHpCard(col)
        } else if (mTab == 2) {
            col.addView(sectionHead("BECERİLER"))
            for (i in 0 until nSk) {
                addSkillCard(col, i)
            }
        } else {
            col.addView(sectionHead("PENCERE"))
            addWindowCard(col)
        }

        val sv = ScrollView(this)
        menuSv = sv
        sv.addView(col)
        val svp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        svp.topMargin = dpx(4)
        root.addView(sv, svp)
        sv.post { sv.scrollTo(0, lastScroll) }

        val wrap = FrameLayout(this)
        wrap.addView(root, FrameLayout.LayoutParams(w0, h0))
        root.pivotX = 0f
        root.pivotY = 0f
        root.scaleX = sca
        root.scaleY = sca
        val ww = (w0 * sca).toInt()
        val hh = (h0 * sca).toInt()
        val lp = menuLp ?: WindowManager.LayoutParams(
            ww,
            hh,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            it.x = (sc[0] - ww) / 2
            it.y = dpx(10)
            menuLp = it
        }
        lp.width = ww
        lp.height = hh
        lp.x = lp.x.coerceIn(0, (sc[0] - ww).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (sc[1] - hh).coerceAtLeast(0))
        drag(tcol, wrap, lp)
        drag(logo, wrap, lp)
        return wrap
    }

    private fun showMenu(on: Boolean) {
        val w = wm ?: return
        if (on && !menuShown) {
            loadCfg()
            removeSafe(menu)
            val fresh = buildMenu()
            val lp = menuLp ?: return
            menu = fresh
            w.addView(fresh, lp)
            menuShown = true
        } else if (!on && menuShown) {
            removeSafe(menu)
            menuShown = false
        }
    }

    // ---------------- servis ----------------

    override fun onServiceConnected() {
        prefs = getSharedPreferences("ayar", MODE_PRIVATE)
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        removeSafe(panel)
        removeSafe(menu)
        menuShown = false
        loadCfg()
        pScale = prefs.getFloat("pscale", 1f).coerceIn(0.6f, 1.6f)
        val d = resources.displayMetrics.density * pScale
        fun dp(v: Int) = (v * d).toInt()

        // yüzen pencere: küçük, mavi-siyah, logodan sürüklenir, logoya dokununca küçülür
        val scr = screen()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = glass(14)
        box.setPadding(dp(6), dp(5), dp(6), dp(5))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(logoRes(if (curGame >= 0) curGame else 0))
        panelLogo = logo
        top.addView(logo, LinearLayout.LayoutParams(dp(34), dp(34)))

        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        val sBtn = symBtn("play", dp(8)) { toggle() }
        startBtn = sBtn
        setRunIcon(running)
        val mBtn = symBtn("menu", dp(8)) { showMenu(!menuShown) }
        for (bv in listOf(sBtn, mBtn)) {
            val p = LinearLayout.LayoutParams(dp(40), dp(34))
            p.leftMargin = dp(5)
            ctl.addView(bv, p)
        }
        top.addView(ctl)
        box.addView(top)

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(2), dp(3), 0, 0)
        val tt = TextView(this)
        tt.textSize = 11f * pScale
        tt.setTextColor(cCyan)
        timeText = tt
        tt.text = pname()
        val st = TextView(this)
        st.textSize = 10f * pScale
        st.setTextColor(cMuted)
        st.maxLines = 3
        st.maxWidth = dp(230)
        statusText = st
        st.text = "parlak = aktif · soluk = bekliyor"
        val ir = LinearLayout(this)
        ir.orientation = LinearLayout.HORIZONTAL
        ir.setPadding(0, dp(4), 0, dp(2))
        iconRow = ir
        info.addView(tt)
        info.addView(ir)
        info.addView(st)
        box.addView(info)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Pencerenin son konumu ve küçültme durumu hatırlanır
        lp.x = prefs.getInt("px", (scr[0] - dp(190)) / 2).coerceIn(0, (scr[0] - dp(60)).coerceAtLeast(0))
        lp.y = prefs.getInt("py", dp(4)).coerceIn(0, (scr[1] - dp(60)).coerceAtLeast(0))
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var collapsed = prefs.getBoolean("col", false)
        logo.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                sx = e.rawX
                sy = e.rawY
                ox = lp.x
                oy = lp.y
                moved = false
            } else if (e.action == MotionEvent.ACTION_MOVE) {
                val dx = e.rawX - sx
                val dy = e.rawY - sy
                if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                if (moved) {
                    lp.x = ox + dx.toInt()
                    lp.y = oy + dy.toInt()
                    try {
                        w.updateViewLayout(box, lp)
                    } catch (ex: Exception) {
                    }
                }
            } else if (e.action == MotionEvent.ACTION_UP) {
                if (moved) {
                    prefs.edit().putInt("px", lp.x).putInt("py", lp.y).commit()
                }
                if (!moved) {
                    collapsed = !collapsed
                    prefs.edit().putBoolean("col", collapsed).commit()
                    ctl.visibility = if (collapsed) View.GONE else View.VISIBLE
                    info.visibility = if (collapsed) View.GONE else View.VISIBLE
                    try {
                        w.updateViewLayout(box, lp)
                    } catch (ex: Exception) {
                    }
                }
            }
            true
        }
        if (collapsed) {
            ctl.visibility = View.GONE
            info.visibility = View.GONE
        }
        box.alpha = pAlpha()
        box.visibility = View.GONE
        panelLp = lp
        w.addView(box, lp)
        panel = box
        rebuildPanelIcons()

        handler.removeCallbacks(scanLoop)
        handler.removeCallbacks(gameLoop)
        handler.post(scanLoop)
        handler.post(gameLoop)
        inst = this
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e != null && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            if (p != null && p != packageName && p != "com.android.systemui") evPkg = p
        }
    }

    override fun onInterrupt() {
        stopAll()
    }

    override fun onDestroy() {
        stopAll()
        handler.removeCallbacks(scanLoop)
        handler.removeCallbacks(gameLoop)
        inst = null
        removeSafe(panel)
        removeSafe(menu)
        worker.shutdown()
        super.onDestroy()
    }
}
