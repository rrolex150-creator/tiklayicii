package com.benim.tiklayici

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.security.MessageDigest

class MainActivity : Activity() {
    companion object {
        // Şifrenin SHA-256 özeti (düz metin olarak saklanmaz)
        private const val PASS_HASH = "f923f0aa486e41d5f89e579b6184cf82c8cc9b2ef2e86a1732968d1e5ff57d2c"
        private const val SESSION_MS = 10 * 60 * 1000L
        private const val UNLOCK_MS = 12 * 60 * 60 * 1000L

        @Volatile
        var lastUnlock = 0L
    }

    private val cBg = 0xFF050506.toInt()
    private val cCard = 0xFF121215.toInt()
    private val cLine = 0xFF2E2E34.toInt()
    private val cAccent = 0xFFD9D9DE.toInt()
    private val cCyan = 0xFFFFFFFF.toInt()
    private val cText = 0xFFFFFFFF.toInt()
    private val cMuted = 0xFF8E8E98.toInt()
    private val cOk = 0xFF4CE08A.toInt()
    private val cWarn = 0xFFFFC857.toInt()
    private val cBad = 0xFFFF6B6B.toInt()

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private var ringAnim: ValueAnimator? = null
    private var statusTitle: TextView? = null
    private var statusSub: TextView? = null
    private var headStatus: TextView? = null
    private var battBtn: TextView? = null
    private var gameBox: LinearLayout? = null
    private var mainShown = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun prefs() = getSharedPreferences("ayar", MODE_PRIVATE)

    private fun rounded(fill: Int, stroke: Int, r: Int, sw: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(r).toFloat()
        if (sw > 0) g.setStroke(dp(sw), stroke)
        return g
    }

    private fun bgGradient(): GradientDrawable {
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF111114.toInt(), 0xFF000000.toInt(), 0xFF16161A.toInt()))
    }

    private fun sha256(t: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(t.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    private fun gameName(g: Int): String {
        val n = prefs().getString("gn_" + g, "") ?: ""
        return if (g >= 3 && n.isNotEmpty()) n else Cfg.GNAME[g]
    }

    private fun migrate() {
        val p = prefs()
        val old = p.getString("game_pkg", "") ?: ""
        val cur = p.getString("gp_0", "") ?: ""
        if (old.isNotEmpty() && cur.isEmpty()) {
            p.edit()
                .putString("gp_0", old)
                .putString("gn_0", p.getString("game_name", "") ?: "")
                .commit()
        }
        if ((p.getString("gp_2", "") ?: "").isEmpty() && packageManager.getLaunchIntentForPackage("com.hardmobile.client") != null) {
            p.edit().putString("gp_2", "com.hardmobile.client").putString("gn_2", "HardMt2").commit()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        migrate()
        root = FrameLayout(this)
        root.background = bgGradient()
        setContentView(root)
        if (System.currentTimeMillis() - lastUnlock < SESSION_MS) {
            showMain(false)
        } else {
            showSplash()
        }
    }

    override fun onResume() {
        super.onResume()
        if (mainShown) {
            refreshStatus()
            refreshGames()
        }
        ui.removeCallbacks(poll)
        ui.postDelayed(poll, 1500L)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        ringAnim?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private val poll = object : Runnable {
        override fun run() {
            if (mainShown) refreshStatus()
            ui.postDelayed(this, 1500L)
        }
    }

    // ---------------- Açılış animasyonu ----------------
    private fun showSplash() {
        mainShown = false
        root.removeAllViews()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val logoBox = FrameLayout(this)
        val ring = View(this)
        val rg = GradientDrawable()
        rg.shape = GradientDrawable.OVAL
        rg.setColor(0x00000000)
        rg.setStroke(dp(2), cCyan)
        ring.background = rg
        ring.alpha = 0f
        logoBox.addView(ring, FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        logo.alpha = 0f
        logo.scaleX = 0.4f
        logo.scaleY = 0.4f
        logoBox.addView(logo, FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER))
        box.addView(logoBox, LinearLayout.LayoutParams(dp(190), dp(190)))

        val title = TextView(this)
        title.text = "OTO AV"
        title.textSize = 32f
        title.letterSpacing = 0.6f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(cCyan)
        title.gravity = Gravity.CENTER
        title.alpha = 0f
        box.addView(title)

        val sub = TextView(this)
        sub.text = "Hazırlanıyor"
        sub.textSize = 13f
        sub.setTextColor(cMuted)
        sub.gravity = Gravity.CENTER
        sub.alpha = 0f
        sub.setPadding(0, dp(6), 0, dp(22))
        box.addView(sub)

        val track = FrameLayout(this)
        track.background = rounded(0x33FFFFFF, 0, 4, 0)
        val fill = View(this)
        val fg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cCyan))
        fg.cornerRadius = dp(4).toFloat()
        fill.background = fg
        fill.pivotX = 0f
        fill.scaleX = 0f
        track.addView(fill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(track, LinearLayout.LayoutParams(dp(210), dp(5)))

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(750L)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
        val ls = ValueAnimator.ofFloat(0.6f, 0.16f)
        ls.duration = 1000L
        ls.interpolator = DecelerateInterpolator()
        ls.addUpdateListener { title.letterSpacing = it.animatedValue as Float }
        ls.start()
        title.animate().alpha(1f).setStartDelay(250L).setDuration(700L).start()
        sub.animate().alpha(1f).setStartDelay(600L).setDuration(500L).start()

        val pulse = ValueAnimator.ofFloat(0f, 1f)
        pulse.duration = 1300L
        pulse.repeatCount = ValueAnimator.INFINITE
        pulse.addUpdateListener {
            val v = it.animatedValue as Float
            ring.scaleX = 0.85f + 0.55f * v
            ring.scaleY = 0.85f + 0.55f * v
            ring.alpha = 0.7f * (1f - v)
        }
        pulse.startDelay = 500L
        pulse.start()
        ringAnim = pulse

        val steps = arrayOf("Hazırlanıyor", "Servis denetleniyor", "Ayarlar yükleniyor", "Hazır")
        for (k in steps.indices) {
            ui.postDelayed({ sub.text = steps[k] }, 450L + k * 520L)
        }
        fill.animate().scaleX(1f).setStartDelay(300L).setDuration(1800L)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                box.animate().alpha(0f).setDuration(300L).withEndAction {
                    ringAnim?.cancel()
                    showLogin()
                }.start()
            }.start()
    }

    // ---------------- Şifre ekranı ----------------
    private fun showLogin() {
        mainShown = false
        root.removeAllViews()
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.gravity = Gravity.CENTER
        wrap.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.addView(wrap, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dp(22), dp(24), dp(22), dp(22))
        card.background = rounded(0xCC121215.toInt(), 0x88FFFFFF.toInt(), 22, 1)
        wrap.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        card.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))

        val t = TextView(this)
        t.text = "OTO AV"
        t.textSize = 24f
        t.letterSpacing = 0.16f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(cCyan)
        t.setPadding(0, dp(10), 0, dp(2))
        card.addView(t)

        val s = TextView(this)
        s.text = "Devam etmek için şifreyi gir"
        s.textSize = 13f
        s.setTextColor(cMuted)
        s.setPadding(0, 0, 0, dp(16))
        card.addView(s)

        val et = EditText(this)
        et.hint = "Şifre"
        et.setHintTextColor(0x888E8E98.toInt())
        et.setTextColor(cText)
        et.textSize = 18f
        et.gravity = Gravity.CENTER
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        et.setSingleLine(true)
        et.background = rounded(0xFF0D0D10.toInt(), cLine, 12, 1)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        card.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val err = TextView(this)
        err.textSize = 12f
        err.setTextColor(cBad)
        err.gravity = Gravity.CENTER
        err.setPadding(0, dp(8), 0, dp(4))
        card.addView(err)

        val go = TextView(this)
        go.text = "Giriş"
        go.textSize = 16f
        go.gravity = Gravity.CENTER
        go.setTypeface(go.typeface, Typeface.BOLD)
        go.setTextColor(0xFF04101F.toInt())
        val gg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cCyan))
        gg.cornerRadius = dp(12).toFloat()
        go.background = gg
        card.addView(go, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))

        fun check() {
            val ok = sha256(et.text.toString().trim()) == PASS_HASH
            if (ok) {
                val now = System.currentTimeMillis()
                lastUnlock = now
                prefs().edit().putLong("unlock_until", now + UNLOCK_MS).commit()
                card.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(320L)
                    .withEndAction { showMain(true) }.start()
            } else {
                err.text = "Şifre yanlış"
                et.setText("")
                val sh = ObjectAnimator.ofFloat(card, "translationX", 0f, -26f, 26f, -18f, 18f, -9f, 9f, 0f)
                sh.duration = 420L
                sh.start()
            }
        }
        go.setOnClickListener { check() }
        et.setOnEditorActionListener { _, _, _ ->
            check()
            true
        }

        card.alpha = 0f
        card.translationY = dp(30).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(520L).setInterpolator(DecelerateInterpolator()).start()
    }

    // ---------------- Ana ekran ----------------
    private fun showMain(animate: Boolean) {
        mainShown = true
        root.removeAllViews()
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(34), dp(18), dp(28))
        sv.addView(col)
        root.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        head.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val hc = LinearLayout(this)
        hc.orientation = LinearLayout.VERTICAL
        hc.setPadding(dp(12), 0, 0, 0)
        val title = TextView(this)
        title.text = "OTO AV"
        title.textSize = 24f
        title.letterSpacing = 0.14f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(cCyan)
        hc.addView(title)
        val hs = TextView(this)
        hs.textSize = 12f
        headStatus = hs
        hc.addView(hs)
        head.addView(hc, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(head)

        col.addView(label("OYUNLARIM"))
        val gb = LinearLayout(this)
        gb.orientation = LinearLayout.VERTICAL
        gameBox = gb
        col.addView(gb)

        val add = TextView(this)
        add.text = "+ Oyun ekle"
        add.textSize = 14f
        add.gravity = Gravity.CENTER
        add.setTypeface(add.typeface, Typeface.BOLD)
        add.setTextColor(cCyan)
        val ag = GradientDrawable()
        ag.setColor(0x00000000)
        ag.cornerRadius = dp(14).toFloat()
        ag.setStroke(dp(1), cAccent, dp(6).toFloat(), dp(4).toFloat())
        add.background = ag
        add.setOnClickListener { addGame() }
        val alp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        alp.topMargin = dp(4)
        col.addView(add, alp)

        col.addView(label("ERİŞİLEBİLİRLİK"))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(12))
        card.background = rounded(cCard, cLine, 14, 1)
        val st = TextView(this)
        st.textSize = 15f
        st.setTypeface(st.typeface, Typeface.BOLD)
        statusTitle = st
        card.addView(st)
        val ss = TextView(this)
        ss.textSize = 12f
        ss.setTextColor(cMuted)
        ss.setPadding(0, dp(2), 0, dp(10))
        statusSub = ss
        card.addView(ss)
        card.addView(button("Erişilebilirlik ayarları", true) {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
                toast("Ayarlar açılamadı")
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        val bb = button("Pil kısıtlamasını kaldır", false) { batteryOpt() }
        battBtn = bb
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        blp.topMargin = dp(8)
        card.addView(bb, blp)
        col.addView(card)

        val how = TextView(this)
        how.text = "Oyunu buradan başlat. Pencere yalnızca seçili oyunda görünür.\n" +
            "Menü düğmesiyle ayarları aç, oynat düğmesiyle başlat. Uygulamayı son uygulamalardan silme, ana ekran tuşuyla çık; yoksa servis kapanabilir."
        how.textSize = 12f
        how.setTextColor(cMuted)
        how.setPadding(dp(4), dp(14), dp(4), 0)
        col.addView(how)

        refreshGames()
        refreshStatus()
        if (animate) {
            sv.alpha = 0f
            sv.translationY = dp(24).toFloat()
            sv.animate().alpha(1f).translationY(0f).setDuration(450L).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun label(t: String): TextView {
        val l = TextView(this)
        l.text = t
        l.textSize = 11f
        l.letterSpacing = 0.14f
        l.setTypeface(l.typeface, Typeface.BOLD)
        l.setTextColor(cMuted)
        l.setPadding(dp(2), dp(18), 0, dp(8))
        return l
    }

    private fun button(text: String, filled: Boolean, act: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 14f
        b.gravity = Gravity.CENTER
        b.setTypeface(b.typeface, Typeface.BOLD)
        if (filled) {
            b.setTextColor(0xFF04101F.toInt())
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cCyan))
            g.cornerRadius = dp(12).toFloat()
            b.background = g
        } else {
            b.setTextColor(cText)
            b.background = rounded(0xFF1A1A1F.toInt(), 0xFF4A4A52.toInt(), 12, 1)
        }
        b.setOnClickListener { act() }
        return b
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    // ---------------- Oyun listesi ----------------
    private fun refreshGames() {
        val box = gameBox ?: return
        box.removeAllViews()
        for (g in 0 until Cfg.GNAME.size) {
            val pkg = prefs().getString("gp_" + g, "") ?: ""
            if (g >= 3 && pkg.isEmpty()) continue
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(10), dp(10))
            row.background = rounded(cCard, cLine, 14, 1)
            val lg = ImageView(this)
            lg.setImageResource(R.drawable.ic_logo)
            row.addView(lg, LinearLayout.LayoutParams(dp(42), dp(42)))
            val tc = LinearLayout(this)
            tc.orientation = LinearLayout.VERTICAL
            tc.setPadding(dp(12), 0, dp(6), 0)
            val nm = TextView(this)
            nm.text = gameName(g)
            nm.textSize = 15f
            nm.setTypeface(nm.typeface, Typeface.BOLD)
            nm.setTextColor(cText)
            tc.addView(nm)
            val pk = TextView(this)
            pk.text = if (pkg.isEmpty()) "Uygulama seçilmedi" else pkg
            pk.textSize = 11f
            pk.setTextColor(if (pkg.isEmpty()) cWarn else cMuted)
            pk.setSingleLine(true)
            tc.addView(pk)
            row.addView(tc, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val act = button(if (pkg.isEmpty()) "Seç" else "Başlat", pkg.isNotEmpty()) {
                if (pkg.isEmpty()) pickApp(g) else launchGame(g)
            }
            row.addView(act, LinearLayout.LayoutParams(dp(80), dp(38)))
            if (pkg.isNotEmpty()) {
                val x = TextView(this)
                x.text = "×"
                x.textSize = 22f
                x.gravity = Gravity.CENTER
                x.setTextColor(cText)
                x.background = rounded(0xFF1A1A1F.toInt(), 0xFF4A4A52.toInt(), 10, 1)
                x.setOnClickListener { removeGame(g) }
                val xp = LinearLayout.LayoutParams(dp(38), dp(38))
                xp.leftMargin = dp(6)
                row.addView(x, xp)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            box.addView(row, lp)
        }
    }

    private fun removeGame(g: Int) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(gameName(g))
            .setMessage("Listeden çıkarılsın mı? Beceri ayarların silinmez.")
            .setPositiveButton("Çıkar") { _, _ ->
                prefs().edit().remove("gp_" + g).remove("gn_" + g).commit()
                refreshGames()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun addGame() {
        var free = -1
        for (g in 3 until Cfg.GNAME.size) {
            if ((prefs().getString("gp_" + g, "") ?: "").isEmpty()) {
                free = g
                break
            }
        }
        if (free < 0) {
            toast("En fazla " + (Cfg.GNAME.size - 3) + " özel oyun eklenebilir")
            return
        }
        pickApp(free)
    }

    private fun pickApp(g: Int) {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        val list = packageManager.queryIntentActivities(i, 0)
        val apps = list.map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        if (apps.isEmpty()) {
            toast("Uygulama listesi alınamadı")
            return
        }
        val names = apps.map { it.first }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Oyunu seç")
            .setItems(names) { _, idx ->
                prefs().edit()
                    .putString("gp_" + g, apps[idx].second)
                    .putString("gn_" + g, apps[idx].first)
                    .commit()
                refreshGames()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun launchGame(g: Int) {
        val pkg = prefs().getString("gp_" + g, "") ?: ""
        val li = if (pkg.isEmpty()) null else packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) {
            toast("Oyun açılamadı")
            return
        }
        if (ClickService.inst == null) {
            toast("Erişilebilirlik servisi kapalı, pencere çıkmaz")
        }
        startActivity(li)
    }

    // ---------------- Servis durumu ----------------
    private fun serviceEnabled(): Boolean {
        val v = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        for (part in v.split(':')) {
            if (part.contains(packageName) && part.endsWith("ClickService")) return true
        }
        return false
    }

    private fun batteryFree(): Boolean {
        return try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            pm.isIgnoringBatteryOptimizations(packageName)
        } catch (e: Exception) {
            false
        }
    }

    private fun batteryOpt() {
        if (batteryFree()) {
            toast("Pil kısıtlaması zaten kapalı")
            return
        }
        try {
            val it = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            it.data = Uri.parse("package:" + packageName)
            startActivity(it)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("Ayar açılamadı")
            }
        }
    }

    private fun refreshStatus() {
        val en = serviceEnabled()
        val run = ClickService.inst != null
        val t: String
        val sub: String
        val col: Int
        if (en && run) {
            t = "Servis çalışıyor"
            sub = "Oyuna girince pencere kendiliğinden çıkar"
            col = cOk
        } else if (en) {
            t = "Ayarda açık ama çalışmıyor"
            sub = "Erişilebilirlik ayarından Oto Av'ı kapatıp tekrar aç"
            col = cWarn
        } else {
            t = "Servis kapalı"
            sub = "Erişilebilirlik ayarından Oto Av'ı aç"
            col = cBad
        }
        statusTitle?.text = t
        statusTitle?.setTextColor(col)
        statusSub?.text = sub
        headStatus?.text = if (en && run) "Servis açık" else "Servis kapalı"
        headStatus?.setTextColor(col)
        battBtn?.text = if (batteryFree()) "Pil kısıtlaması kapalı" else "Pil kısıtlamasını kaldır"
        battBtn?.alpha = if (batteryFree()) 0.55f else 1f
    }
}
